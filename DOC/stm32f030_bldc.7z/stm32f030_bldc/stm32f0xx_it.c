/**
  ******************************************************************************
  * @file    USART/USART_HyperTerminalInterrupt/stm32f0xx_it.c 
  * @author  MCD Application Team
  * @version V1.4.0
  * @date    24-July-2014
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_it.h"
#include "bldc.h"
#include "dc_motor.h"
#include "newprotocol.h"

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M0 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
* @brief  TIM3_IRQ handles HALL switch and calculates speed.
* @param  None
* @retval None
*/
void TIM3_IRQHandler(void)
{
	motor_t *self = &motor;
	static uint16_t cycle = 0;
	static uint32_t tim3tick = 0; 

	if (TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)
	{
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
		if (self->pulse_time < 1000 * 1000)
			self->pulse_time += 65535;
		if (self->pulse_time > 200 * 1000)
			self->fk_spd = 0;
	}

	if (TIM_GetITStatus(TIM3, TIM_IT_CC1) == SET)				
	{
		TIM_ClearITPendingBit(TIM3, TIM_IT_CC1);
		//motor.timeoutofstill = 0;
		//motor.time_stamp[motor.time_pt++ % SPD_CAL_FILTER_LEN] = TIM3->CCR1;
		self->pulse_time += TIM3->CCR1;
		self->pulse += 1;
		static uint16_t hall_err = 0;
		static int last_hall_pos = 0, hall_pos = 0, temp = 0;
		static int spd_dir = 0;
		uint8_t hall = GET_HALL_POS;
		if ((hall < 1) || (hall > 6))
		{
			hall_err++;
			if (hall_err > 3)
			{
				bldc_err.err_bldc_hall = 1;
				serial.err_tx.err |= ERR_RTU_INTERNAL;
				disable_bldc(&motor);
				hall_err = 0;
			}

		}
		else
			hall_err = 0;

		hall_pos = self->hall_tbl[hall];

		if (hall_pos == (last_hall_pos + 1) % 6)
			spd_dir = 1;
		else if (hall_pos == (last_hall_pos + 5) % 6)
			spd_dir = -1;
		else
		{
			hall_err++;
			if (hall_err > 3)
			{
				bldc_err.err_bldc_hall = 1;
				serial.err_tx.err |= ERR_RTU_INTERNAL;
				disable_bldc(&motor);
				hall_err = 0;
			}

		}

		last_hall_pos = hall_pos;
		if ((self->pulse >= 4) || (self->pulse_time > 100 * 1000))
		{
			float spd = (1000000.0 * self->pulse) / (self->pulse_time * self->poles * 6.0);
			if (spd_dir < 0)
				spd = -spd;
			self->fk_spd = spd;
			self->pulse = 0;
			self->pulse_time = 0;
		}

		if (motor.calibrate == TRUE)
		{
			if (motor.dir == POSITIVE)
			{
				motor.hall_tbl[hall] = motor.cur_phase;
				motor.status |= 1 << hall;
				motor.calibrate = FALSE;
				for (int i = 1; i < 6; i++)
				{
					if ((motor.hall_tbl[i] == 0)||(motor.hall_tbl[i] == 0xffffffff))
					{
						motor.calibrate = TRUE;
						break;
					}
					for (int j = i + 1; j < 7; j++)
					{
						if (motor.hall_tbl[i] == motor.hall_tbl[j])
						{
							motor.calibrate = TRUE;
							i = 6;
							j = 7;
							break;
						}
					}
				}
			}
			else if (motor.dir == NEGATIVE)
			{
				motor.hall_tbl_rt[hall] = motor.cur_phase;
				motor.status |= 1 << hall;
				motor.calibrate = FALSE;
				for (int i = 1; i < 6; i++)
				{
					if ((motor.hall_tbl_rt[i] == 0) || (motor.hall_tbl_rt[i] == 0xffffffff))
					{
						motor.calibrate = TRUE;
						break;
					}
					for (int j = i + 1; j < 7; j++)
					{
						if (motor.hall_tbl_rt[i] == motor.hall_tbl_rt[j])
						{
							motor.calibrate = TRUE;
							i = 6;
							j = 7;
							break;
						}
					}
				}
			}
			
		}
		else
		{
			
		}
	}

	if (TIM_GetITStatus(TIM3, TIM_IT_CC2) == SET)
	{
		TIM_ClearITPendingBit(TIM3, TIM_IT_CC2);
	}
	else if (TIM_GetITStatus(TIM3, TIM_IT_CC3) == SET)
	{
		TIM_ClearITPendingBit(TIM3, TIM_IT_CC3);

	}
	else if (TIM_GetITStatus(TIM3, TIM_IT_CC4) == SET)
	{
		TIM_ClearITPendingBit(TIM3, TIM_IT_CC4);
	}
	else if (TIM_GetITStatus(TIM3, TIM_IT_Trigger) == SET)
	{
		TIM_ClearITPendingBit(TIM3, TIM_IT_Trigger);
	}
	
}
/**
* @brief  This function handles TIM1 Break, Update, Trigger and Commutation interrupt request.
* @param  None
* @retval None
*/
void TIM1_BRK_UP_TRG_COM_IRQHandler(void)
{
	if (motor.enabled == 1 && motor.calibrate == FALSE && motor.tar_spd != 0)
	{
		bldc_switch(&motor);
	}
	static int last_hall_pos = 0, hall_pos = 0, temp = 0;
	static int spd_dir = 0;
	if (temp == 0)  // for the first time get in
	{
		temp++;
		last_hall_pos = motor.hall_tbl[GET_HALL_POS];
		hall_pos = last_hall_pos;
	}
	
	uint8_t hall = GET_HALL_POS;
	static uint16_t hall_err = 0;

	if ((hall < 1) || (hall > 6))
	{
		hall_err++;
		if (hall_err > 3)
		{
			bldc_err.err_bldc_hall = 1;
			serial.err_tx.err |= ERR_RTU_INTERNAL;
			disable_bldc(&motor);
			hall_err = 0;
		}
	}
	else
		hall_err = 0;

	hall_pos = motor.hall_tbl[hall];

	if ((hall_pos == last_hall_pos + 1) || (hall_pos == (last_hall_pos + 1) % 6) )
	{
		motor.pos++;
	}
	else if ( (hall_pos == last_hall_pos - 1) || (hall_pos == last_hall_pos + 5) )
	{
		motor.pos--;
	}

	last_hall_pos = hall_pos;

	TIM_ClearITPendingBit(TIM1, TIM_IT_COM);
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */

void SysTick_Handler(void)
{
	IWDG_ReloadCounter();
	/*fftĿ���ٶȺ�ʵ���ٶȲ���*/
	static int cnt = 0;
	motor.fk_spd_fft[cnt] = motor.fk_spd;
	motor.tar_spd_fft[cnt] = motor.tar_spd;
	cnt++;
	if (cnt>31)
	{
		cnt = 0;
	}
	motor.timeoutofstill++;
	if (ms_timer > 0)
	{
		ms_timer--;
	}
    /*5����1s��ʱ�洢����ֵ������������*/
	motor.i_bus_count_tick++;
    /*1s��ʱ�����ʧ�ܱ������*/
	if (adc_dma[I_BUS_ADC]>2000)
	{
		motor.i_bus_max_count_tick++;
		if (motor.i_bus_max_count_tick > 1000)
		{
//			disable_bldc(&motor);
			//bldc_err.err_bldc_dangerous = 1;
		}
	}
	else
	{
		motor.i_bus_max_count_tick = 0;
		//bldc_err.err_bldc_dangerous = 0;
	}
	/* 20ms��ʱ���ٶȺͱ�����ֵ���ظ�motherboard*/
	static uint16_t encode_count_tick = 0;
	encode_count_tick++;
	if (encode_count_tick >= 20)
	{
		if (serial.encode_timeout != 1)
		{
			serial.encode_timeout = 1;
		}
		encode_count_tick = 0;
	}
	/*���������ת����*/
	if ((motor.enabled == 1) && (motor.calibrate == FALSE) && (((motor.duty)/ (fabs(motor.fk_spd)+0.01 ))>200000)&&(fabs(motor.fk_spd)<5))
	{
		motor.timeoutofoctremble++;
		if (motor.timeoutofoctremble>1000)
		{
			bldc_err.err_bldc_oc_tremble = 1;
//			disable_bldc(&motor);
			motor.timeoutofoctremble = 0;
		}
		
	}
	else if (((motor.duty) / (fabs(motor.fk_spd) + 0.01)) < 200000)
	{
		motor.timeoutofoctremble = 0;
		bldc_err.err_bldc_oc_tremble = 0;
	}
	/*�������PIDʵʱ������*/
	if ((motor.enabled == 1) && (motor.calibrate == FALSE) && \
		((motor.timeoutofcontrol == 0) || (motor.watchdog <= motor.timeoutofcontrol)))
	{
		motor.watchdog++;
		bldc_update(&motor);
	
// 		if (motor.status == TEST)
// 		{
// 			if (motor.cnt < 1024)
// 			{
// 				motor.fk_spd_buf[motor.cnt] = motor.fk_spd;
// 				motor.fk_output[motor.cnt] = motor.pid.output;
// 				motor.cnt++;
// 			}
// 		}
		bldc_switch(&motor);
	}
	else if ((motor.watchdog > motor.timeoutofcontrol)&& (motor.enabled == 1))
	{
		motor.tar_spd = 0;
		bldc_update(&motor);
		bldc_switch(&motor);
	}
#if 1
	/*����������ڵڶ���֮��ֹͣ�����ת*/
	if (dc_motor.wheel_down_angle_value < 2000)  //����������
	{
		if ((dc_motor.pos1_arrive_time != 0) && (adc_dma[WHEEL_ANGLE_ADC] < (dc_motor.wheel_down_angle_value + 600)))
		{
			dc_motor_right_position_update(251);
		}
	}
	else if (dc_motor.wheel_down_angle_value > 2000)   //����������
	{
		if ((dc_motor.pos1_arrive_time != 0) && (adc_dma[WHEEL_ANGLE_ADC] > (dc_motor.wheel_down_angle_value - 600)))
		{
			dc_motor_left_position_update(251);
		}
	}
	/*����������ڵ�һ��֮��ֹͣ�����ת*/
	if ((dc_motor.pos2_arrive_time != 0) && (POS_ARRIVED_SIG != GET_POS2_ARRIVE))
	{
		dc_motor.pos2_arrive_time++;
		if (dc_motor.pos2_arrive_time > dc_motor.para.set_pos_tremble_timeout)
		{
			uint16_t duty1, duty2;
			duty1 = TIM15->CCR1;
			duty2 = TIM15->CCR2;
			TIM15->CCR1 = duty1 / 2;
			TIM15->CCR2 = duty2 / 2;
			if ((duty1 < 3) && (duty2 < 3))
			{
				TIM15->CCR1 = 0;
				TIM15->CCR2 = 0;
				duty1 = 0;
				duty2 = 0;
				TIM_GenerateEvent(TIM15, TIM_EventSource_Update);
				TIM_Cmd(TIM15, DISABLE);
				dc_motor.pos2_arrive_time = 0;
				dc_motor.pos_from_start = 0;
				dc_motor.dc_motor_second_gear_flag = 1;
			}
			
		}
	}
	else if (dc_motor.pos2_arrive_time != 0)
	{
		dc_motor.pos2_arrive_time = 1;
	}
	/*�������������up֮��ֹͣ�����ת*/
	if ((dc_motor.pos3_arrive_time != 0) && (POS_ARRIVED_SIG != GET_POS3_ARRIVE))
	{
		dc_motor.pos3_arrive_time++;
		if (dc_motor.pos3_arrive_time > dc_motor.para.set_pos_tremble_timeout)
		{
			uint16_t duty1, duty2;
			duty1 = TIM15->CCR1;
			duty2 = TIM15->CCR2;
			TIM15->CCR1 = duty1 / 2;
			TIM15->CCR2 = duty2 / 2;
			if ((duty1 < 3) && (duty2 < 3))
			{
				TIM15->CCR1 = 0;
				TIM15->CCR2 = 0;
				duty1 = 0;
				duty2 = 0;
				TIM_GenerateEvent(TIM15, TIM_EventSource_Update);
				TIM_Cmd(TIM15, DISABLE);
				bldc_dc_status.dc_wheel_status = 1;
				dc_motor.pos3_arrive_time = 0;
				dc_motor.pos_from_start = 0;
			}
			
		}
	}
	else if (dc_motor.pos3_arrive_time != 0)
	{
		dc_motor.pos3_arrive_time = 1;
	}
	/*�����ֵ��4s��ʱ���*/
	if (dc_motor.pos_from_start != 0)
	{
		dc_motor.pos_from_start++;
		if (dc_motor.pos_from_start > dc_motor.para.set_updown_timeout)
		{
			uint16_t duty1, duty2;
			duty1 = TIM15->CCR1;
			duty2 = TIM15->CCR2;
			TIM15->CCR1 = duty1 / 2;
			TIM15->CCR2 = duty2 / 2;
			if ((duty1 < 3) && (duty2 < 3))
			{
				TIM15->CCR1 = 0;
				TIM15->CCR2 = 0;
				duty1 = 0;
				duty2 = 0;
				TIM_GenerateEvent(TIM15, TIM_EventSource_Update);
				TIM_Cmd(TIM15, DISABLE);
				bldc_dc_status.dc_wheel_status = 4;
				dc_motor.pos1_arrive_time = 0;
				dc_motor.pos2_arrive_time = 0;
				dc_motor.pos3_arrive_time = 0;
				dc_motor.pos_from_start = 0;
				dc_motor.over_current_time = 0;
				dc_motor.dc_motor_second_gear_start = 0;
			}
			
		}
	}
#endif
	/*�����ֵ���������*/
	if ((dc_motor.over_current_time != 0) && (Bit_RESET == GET_MC_NOT_OC))
	{
		dc_motor.over_current_time++;
		if (dc_motor.over_current_time > dc_motor.para.set_oc_tremble_timeout)
		{
			uint16_t duty1, duty2;
			duty1 = TIM15->CCR1;
			duty2 = TIM15->CCR2;
			TIM15->CCR1 = duty1 / 2;
			TIM15->CCR2 = duty2 / 2;
			if ((duty1<3)&& (duty2<3))
			{
				TIM15->CCR1 = 0;
				TIM15->CCR2 = 0;
				duty1 = 0;
				duty2 = 0;
				TIM_GenerateEvent(TIM15, TIM_EventSource_Update);
				TIM_Cmd(TIM15, DISABLE);
				bldc_dc_status.dc_wheel_status = 3;
				dc_motor.over_current_time = 0;
				dc_motor.pos_from_start = 0;
				dc_motor.dc_motor_second_gear_flag = 1;
			}
			
		}
	}
	else if (dc_motor.over_current_time != 0)
	{
		dc_motor.over_current_time = 1;
	}
	/*�ж��Ƿ��������Է�ֹ���ӱ�����*/
	if ((dc_motor.dc_motor_second_gear_flag == 1) && (dc_motor.wheel_angle_studied_flag == 1))
	{
		static  second_gear_count_timeout;
		static  second_gear_count = 0;
		static  first_gear_count = 0;
		if ((GET_HALL4_STATUS == Bit_SET) || (GET_HALL3_STATUS == Bit_SET) || (GET_HALL5_STATUS == Bit_SET))
		{
			second_gear_count++;
			if (second_gear_count > 100)
			{
				dc_motor.dc_motor_second_gear_start = 1;
				dc_motor.dc_motor_second_gear_flag = 0;
				second_gear_count_timeout = 0;
				second_gear_count = 0;
			}
		}
		else
		{
				bldc_dc_status.dc_wheel_status = 2;
				second_gear_count = 0;
				first_gear_count = 0;
		}
		second_gear_count_timeout++;
		if (second_gear_count_timeout>1000)
		{
			bldc_dc_status.dc_wheel_status = 2;
			dc_motor.dc_motor_second_gear_flag = 0;
			second_gear_count_timeout = 0;
		}
	}
    /*��⵽���ӱ���������������������ڶ���*/
	if ((dc_motor.dc_motor_second_gear_start == 1) && (dc_motor.wheel_angle_studied_flag == 1))
	{
		TIM_Cmd(TIM15, ENABLE);
		TIM15->CCR2 = dc_motor.para.set_max_pwm;
		bldc_dc_status.dc_wheel_status = 0;
		if (dc_motor.wheel_down_angle_value < 2000)
		{
			dc_motor_right_position_update(251);
		}
		else if (dc_motor.wheel_down_angle_value > 2000)
		{
			dc_motor_left_position_update(251);
		}
		
	}
	/*�����ֿ�ʼ����*/
	if (dc_motor.dc_motor_liftup_state == TRUE)// && (Bit_SET != GET_POS3_ARRIVE))
	{
		static  duty = 0;
		if (duty < dc_motor.para.set_max_pwm)
		{
			TIM_Cmd(TIM15, ENABLE);
			duty = duty + dc_motor.para.set_duty_step;
			TIM15->CCR2 = duty;
			bldc_dc_status.dc_wheel_status = 0;
		}
		else
		{
			TIM15->CCR2 = dc_motor.para.set_max_pwm;
			dc_motor.dc_motor_liftup_state = FALSE;
			duty = 0;
		}
	}
	/*�����ֿ�ʼ�½�*/
	if (dc_motor.dc_motor_liftdown_state == TRUE) //&& (Bit_SET != GET_POS2_ARRIVE))
	{
		static duty = 0;
		if (duty < dc_motor.para.set_max_pwm)
		{
			TIM_Cmd(TIM15, ENABLE);
			duty = duty + dc_motor.para.set_duty_step;
			TIM15->CCR1 = duty;
			bldc_dc_status.dc_wheel_status = 0;
		}
		else
		{
			TIM15->CCR1 = dc_motor.para.set_max_pwm;
			dc_motor.dc_motor_liftdown_state = FALSE;
			duty = 0;
		}
	}
}

void TIM14_IRQHandler()
{
	if (TIM_GetFlagStatus(TIM14, TIM_FLAG_Update) == SET)
	{
		serial.system_timeseq++;
		if (ms_timer > 0)
		{
			ms_timer--;
		}
		TIM_ClearITPendingBit(TIM14, TIM_FLAG_Update);
	}
}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
