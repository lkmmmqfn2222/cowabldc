#ifndef  __MODBUS_H__
#define  __MODBUS_H__

#include "bldc.h"
#include "R1_Protocol.h"
#include "R1_data_struct.h"
#include "dc_motor.h"

/* define  */
#define   BROADCAST_ADDR			 0x00ff

/* define all  READ & WRITE register address */
#define   ADDR_DRV_ADDR_REG			 0x0001
#define   ADDR_CONROL_MODE_REG	     0x0002
#define   ADDR_SPD_PID_KP_REG		 0x0003
#define   ADDR_SPD_PID_KI_REG		 0x0004
#define   ADDR_STALL_TIMEOUT_REG	 0x0005
#define   ADDR_COMM_TIMEOUT_REG		 0x0006
									 
#define   ADDR_BLDC_ENBLE_REG		 0x0007
#define   ADDR_SPD_REG				 0x0008
#define   ADDR_DUTY_REG				 0x0009
#define   ADDR_POLES_REG			 0x000b
#define   ADDR_CLEAR_ERR_REG		 0x000a
#define   ADDR_DCM_LIFTUP_REG		 0x000c
#define   ADDR_DCM_LIFTDOWN_REG		 0x000d
#define   ADDR_SAVE_PARA_REG		 0x0010
#define   ADDR_IDENTIFY_REG			 0x000f
#define   ADDR_SPD_PID_K_REG         0x0011


/* DC_CONTORL  PARAMETERS */
#define   ADDR_DC_OCTREMBLE_REG		 0x0020	
#define   ADDR_DC_POSTREMBLE_REG	 0x0021
#define   ADDR_DC_MAX_PWM_REG		 0x0022
#define   ADDR_DC_PWM_STEP_REG       0x0023
#define   ADDR_DC_UPDOWN_TIMEOUT_REG 0x0024
#define   ADDR_SPD_PRINT_REG         0x0025

/* define READ ONLY register address */
#define   ADDR_STATUS_REG			0x0080
#define   ADDR_POS_REG				0x0081
#define	  ADDR_DC_POS_ADC_REG		0x0082
#define   ADDR_ERROR_REG			0x0083
#define   ADDR_VERSION_STR_REG      0x0086


typedef enum{
	ERR_BLDC_HALL = 0x0001,
	ERR_BLDC_COMM = 0x0002,
	ERR_BLDC_SPD  = 0x0004,
	ERR_BLDC_STALL = 0x0008,
	ERR_DC_MT = 0x0010,
	ERR_PARA_SAVE = 0x0020,	
	ERR_MOTOR_OC_TREMBLE = 0x0040,
	ERR_DC_MT_WRONG_STATE = 0x0080,
}error_bldc_t;
typedef enum {
	STATUS_DC_MT_UP = 0x0001,
	STATUS_DC_MT_DOWN = 0x0002,
	STATUS_DC_MT_RUNNING = 0x0004,
}status_dc_t;

typedef enum{
	SPD_MODE = 1,
	TOQ_MODE,
	POS_MODE,
}control_mode_t;

typedef enum{ READ_REG = 3, WRITE_REG = 6, READ_WRITE_NOSTANDARD_REG = 9, WRITE_MUL_REG = 0x10, INFO_REQUIRE = 0x80 }func_code_t;
typedef enum{
	ERR_RTU_FUN_CODE = 0x01,
	ERR_RTU_REG_ADDR = 0x02,
	ERR_RTU_DATA_ERR = 0x03,
	ERR_RTU_INTERNAL = 0x04,
	ERR_RTU_CONFIRM  = 0x05,  // confirm command & handling now
	ERR_RTU_SLAVE_BUSY	 = 0x06,
	ERR_RTU_PARITY	 = 0x08,
	ERR_RTU_GATEWAY  = 0x0a,
}err_code_t;
typedef enum{ WAITING = 1, FIND_ADDR, FIND_FUNC, RX_REG_Hi, RX_REG_Lo, RX_DATA_Hi, RX_DATA_Low,\
			  RX_CRC_Hi, RX_FINISH}rtu_state_t;
typedef enum{ SERIAL_READY = 1, SERIAL_TIMEOUT }serial_state_t;

#define COWA_FK_SPEED_LEN  2
#define COWA_MOTOR_ERR_LEN  1
#define COWA_MOTOR_POS_LEN  4
#define COWA_MOTOR_BLDC_DC_STATUS_LEN  1
#define COWA_BLDC_DC_PARA_LEN  26
typedef struct
{
	uint8_t addr;
	uint8_t code;
	uint8_t reg_hi;
	uint8_t reg_lo;
	uint8_t data_hi;
	uint8_t data_lo;
	uint8_t crc_hi;
	uint8_t crc_lo;
}rtu_rx;
typedef struct
{
	uint8_t addr;
	uint8_t code;
	uint8_t spd1_hi;
	uint8_t spd1_lo;
	uint8_t spd2_hi;
	uint8_t spd2_lo;
	uint8_t crc_hi;
	uint8_t crc_lo;
}rtu_nostd_rx;
typedef struct 
{
	uint8_t addr;
	uint8_t code;
	uint8_t byte_len;
	uint8_t data_hi;
	uint8_t data_lo;
	uint8_t crc_hi;
	uint8_t crc_lo;
}rtu_tx;
typedef struct  
{
	uint8_t addr;
	uint8_t fun_code_err;
	uint8_t err;
	uint8_t crc_hi;
	uint8_t crc_lo;
}err_tx_t;
typedef union
{
	uint8_t buf[8];
	rtu_rx rtu;
	rtu_nostd_rx rtu_nostd;
}rx_t;

typedef struct 
{
	rx_t			rx_data;
	rtu_tx			tx_data;
	uint16_t		data_len;
	serial_state_t  state;
	err_tx_t		err_tx;
	uint8_t         encode_timeout;
	uint32_t        system_timeseq;
	uint32_t        count_receive_dma;
	uint32_t        count_send_dma;
}com_t;

//volatile cowa_packet_data_abstract_t receive_data;
extern cowa_packet_control_abstract_t receive_data;
extern cowa_packet_data_abstract_t send_data_buffer;
extern cowa_frame_t send_fram_dma;
extern com_t serial;
extern uint8_t receive_dma[CIRCUL_BUF_LEN];
extern uint16_t adc_dma[2];
extern system_switch_cmd_t system_switch_executed_ack;
extern bldc_error_rate bldc_package_cnt;
extern bldc_dc_status_t bldc_dc_status;
extern bldc_error_status_t bldc_err;
void send_to_master(uint8_t* buf, uint16_t size);
void new_protocol_handler();

#endif