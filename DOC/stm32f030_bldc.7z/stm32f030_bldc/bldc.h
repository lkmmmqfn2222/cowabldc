#ifndef  __BLDC_H__
#define  __BLDC_H__

#include "stm32f0xx_conf.h"
#include "bsp.h"
#include "R1_data_struct.h"
//#include "modbus.h"
/* 0x0800 0000 + 60K */
#define  HALL_TBL_ADDR		0x0800f800

#define  CONTROL_PERIOD			1	// ms
#define  SPD_CAL_FILTER_LEN		6	// define speed calculation filter
#define  MIN_ERR				0.5  //0.2
#define  MAX_PWM_DUTY			2399
#define  TIMEOUT_OF_STILL		500   //ms
#define  TIMEOUT_OF_CONTROL		2000
#define  BLDC_STILL_DEAD_ZONE	0.2  // rps


#define  EN_CH1N   GPIO_SetBits(GPIOB, GPIO_Pin_13);
#define  EN_CH2N   GPIO_SetBits(GPIOB, GPIO_Pin_14);
#define  EN_CH3N   GPIO_SetBits(GPIOB, GPIO_Pin_15);
#define  DIS_CH1N    GPIO_ResetBits(GPIOB, GPIO_Pin_13);
#define  DIS_CH2N    GPIO_ResetBits(GPIOB, GPIO_Pin_14);
#define  DIS_CH3N    GPIO_ResetBits(GPIOB, GPIO_Pin_15);

#define  EN1_EN2_DIS3	EN_CH1N;EN_CH2N;EN_CH3N;
#define  EN1_DIS2_EN3	EN_CH1N;DIS_CH2N;EN_CH3N;
#define  DIS1_EN2_EN3   DIS_CH1N;EN_CH2N;EN_CH3N;

#define  GET_HALL_POS  (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0)+GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4)*2+GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5)*4)

#define STEP1(DUTY) EN_CH1N;\
	EN_CH2N;\
	DIS_CH3N;\
	TIM1->CCR1 = DUTY;\
	TIM1->CCR2 = 0;	\
	TIM1->CCR3 = 0; \

#define STEP2(DUTY)	EN_CH1N;\
	DIS_CH2N;\
	EN_CH3N;\
	TIM1->CCR1 = DUTY;\
	TIM1->CCR2 = 0;\
	TIM1->CCR3 = 0;

#define STEP3(DUTY) DIS_CH1N;\
	EN_CH2N;\
	EN_CH3N;\
	TIM1->CCR1 = 0;\
	TIM1->CCR2 = DUTY;\
	TIM1->CCR3 = 0;

#define STEP4(DUTY) EN_CH1N;\
	EN_CH2N;\
	DIS_CH3N;\
	TIM1->CCR1 = 0;\
	TIM1->CCR2 = DUTY;\
	TIM1->CCR3 = 0;

#define STEP5(DUTY) EN_CH1N;\
	DIS_CH2N;\
	EN_CH3N;\
	TIM1->CCR1 = 0;\
	TIM1->CCR2 = 0;\
	TIM1->CCR3 = DUTY;

#define STEP6(DUTY) DIS_CH1N;\
	EN_CH2N;\
	EN_CH3N;\
	TIM1->CCR1 = 0;\
	TIM1->CCR2 = 0;\
	TIM1->CCR3 = DUTY
typedef enum {NEGATIVE =-1, POSITIVE = 1}dir_t;
typedef enum {FALSE = 0, TRUE = 1}bool_t;
typedef enum {ONE = 1, TWO, THREE, FOUR, FIVE, SIX}phase_t;
typedef enum {NORMAL = 0, CALIBRATION, TEST}status_t;

typedef struct
{
	float err;
	float err_err;
	float last_err;
	float ui;
	float ud;
	float imax;
	float imin;
	float kp;
	float ki;
	float kd;
	float output;
	float last_output;
	float k;
	float ki_flash;

}pid_contorller_t;

typedef struct
{
	uint32_t hall_tbl[8];
	uint32_t hall_tbl_rt[8];
	uint32_t poles;
	phase_t  cur_phase;
	phase_t  next_phase;
	uint16_t enabled;
	uint16_t duty;
	float    tar_spd;
	float    tar_spd_fft[32];
	float    tar_duty;
	volatile float    fk_spd;
	float    fk_spd_fft[32];
	int16_t  fk_spd_int;
	uint16_t fk_spd_pid;
	dir_t    dir;
	bool_t	 calibrate;
	status_t status;
	uint16_t time_stamp[SPD_CAL_FILTER_LEN];
	uint16_t time_pt;
	pid_contorller_t pid;
// 	int16_t  fk_spd_buf[1024];
// 	int16_t  fk_output[1024];
	uint16_t cnt;
	uint32_t timeoutofcontrol;
	uint32_t timeoutofstill;
	uint32_t timeoutofoctremble;
	uint32_t ctrl_mode;
	uint8_t  err;
	int32_t  pos;
	uint32_t watchdog;
	uint8_t  motor_enabled_flag;
	uint32_t motor_enabled_seq;
	uint8_t  motor_learning_flag;
	uint32_t motor_learning_seq;
	uint8_t  motor_set_speed_flag;
	uint32_t motor_set_speed_seq;
	uint8_t  motor_set_duty_flag;
	uint32_t motor_set_duty_seq;
	uint8_t  bldc_sensor_state;
	uint16_t i_bus_count_tick;
	uint16_t i_bus_max_count_tick;
	uint8_t i_bus_max_count_flag;
	uint8_t  motor_clear_err_flag;
	uint32_t motor_clear_err_seq;

	int16_t pulse;
	int32_t pulse_time;
}motor_t;

typedef struct
{
	uint32_t hall_tbl[8];
	uint32_t hall_tbl_rt[8];
	pid_contorller_t pid;
	uint32_t poles;	// z
	uint32_t ctrl_mode;
	uint32_t timeout;
}parameters_t;

extern motor_t motor;

/**
* @brief  initialize all drivers that are needed, reset pid_controller,
*		  set default parameters for motor
* @param  void
* @note	  setup hall detector(TIM3), setup PWM output(TIM1), configure L6230.
* @retval None
*/
void bldc_init();
/**
* @brief  save all parameters of bldc motor
* @param  void
* @note	  hall_tbl, hall_tbl_rvt, pid, poles.
* @retval None
*/
int bldc_save(motor_t* self);
/**
* @brief  enable motor
* @param  void
* @note   enable L6230 and set motor.enable = 1
* @retval None
*/
void enable_bldc(motor_t *self);
/**
* @brief  disable motor
* @param  void
* @note   disable L6230 and set motor.enable = 0
* @retval None
*/
void disable_bldc(motor_t *self);
/**
* @brief  detect motor hall phase and fill the hall table
* @param  void
* @note   save the hall table at HALL_TBL_ADDR in flash
* @retval None
*/
int  bldc_com_identify(motor_t *self);
/**
* @brief  switch PWM to the next step according to hall table
* @param  void
* @note   
* @retval None
*/
void bldc_switch(motor_t *self);
/**
* @brief  start motor
* @param  void
* @note   call bldc_swtich to trigger hall commutation
* @retval None
*/
void bldc_start(motor_t* self);
/**
* @brief  update motor control 
* @param  void
* @note   motor spd cacualte; pid update.
* @retval None
*/
void bldc_update(motor_t* self);
/**
* @brief  load parameters of bldc_motor
* @param  void
* @note   Poles, Hall_Sequence, Pid
* @retval None
*/
void bldc_load_para(motor_t *self);
/**
* @brief  initialize pid_controller to default values
* @param  void
* @note   Kp = 20, Ki = 0.1
* @retval None
*/
void pid_init(pid_contorller_t * self);
/**
* @brief  reset ui to 0
* @param  void
* @note   
* @retval None
*/
void pid_reset(pid_contorller_t * self);
/**
* @brief  calculate pid and update 
* @param  void
* @note   called by bldc_update()
* @retval None
*/
float pid_update(pid_contorller_t * self, float tar_spd, float fk_spd);

void print_info(motor_t *self);

#endif uint16_t tar_duty; uint16_t tar_duty;