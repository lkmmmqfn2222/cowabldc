#include "bldc.h"
#include "stdio.h"
#include "newprotocol.h"
#include <math.h>
#include "machine\fastmath.h"
#include "print.h"
#include "dc_motor.h"
#include "stm32f0xx_it.h"
/**
* @brief  initialize all drivers that are needed, reset pid_controller,
*		  set default parameters for motor
* @param  void
* @note	  setup hall detector(TIM3), setup PWM output(TIM1), configure L6230.
* @retval None
*/
void bldc_init()
{
	init_drv();
	hall_tim3_config();
	pwm_tim1_config();
	pid_init(&motor.pid);
	motor.poles = 8;
	motor.dir = POSITIVE;
	motor.timeoutofstill = 0;
	motor.watchdog = 0;
	serial.encode_timeout = 0;
	/*�ϵ�������ֵĳ�ʼ״̬�ж�*/
	dc_motor_para_t dc_para;
	dc_para = *(dc_motor_para_t*)(DC_MOTOR_PARA_ADDR);
	if (dc_para.wheel_up_angle_value>2000)    //������
	{
		if (adc_dma[WHEEL_ANGLE_ADC] > 2000)
		{
			bldc_dc_status.dc_wheel_status = 1;
		}
		else if (adc_dma[WHEEL_ANGLE_ADC] < 2000)
		{
			bldc_dc_status.dc_wheel_status = 2;
		}
	}
	else if (dc_para.wheel_up_angle_value < 2000)     //������
	{
		if (adc_dma[WHEEL_ANGLE_ADC] > 2000)
		{
			bldc_dc_status.dc_wheel_status = 2;
		}
		else if (adc_dma[WHEEL_ANGLE_ADC] < 2000)
		{
			bldc_dc_status.dc_wheel_status = 1;
		}
	}
	motor.pos = 0;
	motor.ctrl_mode = 1;
	bldc_load_para(&motor);
	motor.enabled = 0;
}
/**
* @brief  enable motor
* @param  void
* @note   enable L6230 and set motor.enable = 1
* @retval None
*/
void enable_bldc(motor_t *self)
{
	//pid_reset(&self->pid);
	self->enabled = 1;
	motor.pid.ui = 0;
	motor.tar_spd = 0;
//	bldc_err.err_bldc_dangerous = 0;
	bldc_err.err_bldc_hall = 0;
	bldc_err.err_bldc_hot = 0;
	bldc_err.err_bldc_vibration = 0;
	bldc_err.err_bldc_oc_tremble = 0;
	motor.duty = 0;
}
/**
* @brief  disable motor
* @param  void
* @note   disable L6230 and set motor.enable = 0
* @retval None
*/
void disable_bldc(motor_t *self)
{
	self->enabled = 0;
	motor.pid.ui = 0;
	motor.tar_spd = 0;
	motor.tar_duty = 0;
	motor.duty = 0;
	DIS_CH1N; 
	DIS_CH2N;
	DIS_CH3N;
 	pid_reset(&self->pid);
}
/**
* @brief  detect motor hall phase and fill the hall table
* @param  void
* @note   save the hall table at HALL_TBL_ADDR in flash
* @retval None
*/
int bldc_com_identify(motor_t *self)
{
	/* find duty to have motor rotate */
	int16_t cur_step = 0, last_step = 0;
	self->calibrate = TRUE;
	self->duty = 399;
	uint16_t phase = 0;
	self->cur_phase = 1;
	STEP1(self->duty);
	ms_sleep(500);
	self->dir = POSITIVE;
	for (int i = 0; i < 8;i++)
	{
		self->hall_tbl[i] = 0;
		self->hall_tbl_rt[i] = 0;
	}
	do 
	{
		self->cur_phase = self->cur_phase % 6 + 1;
		switch (self->cur_phase)
		{
		case 1:
			STEP1(self->duty);
			ms_sleep(1000);
			break;
		case 2:
			STEP2(self->duty);
			ms_sleep(1000);
			break;
		case 3:
			STEP3(self->duty);
			ms_sleep(1000);
			break;
		case 4:
			STEP4(self->duty);
			ms_sleep(1000);
			break;
		case 5:
			STEP5(self->duty);
			ms_sleep(1000);
			break;
		case 6:
			STEP6(self->duty);
			ms_sleep(1000);
			break;
		}
		
	} while (self->calibrate == TRUE);
	
	for (int i = 1; i < 7; i++)
		self->hall_tbl_rt[7 - i] = self->hall_tbl[i];

	self->duty = 0;
	bldc_switch(self);

	self->duty = 0;
	self->hall_tbl[7] = 0x12344321;
	if (self->hall_tbl[1]==0||self->hall_tbl[2]==0 || self->hall_tbl[3] ==0|| \
		self->hall_tbl[4]==0 || self->hall_tbl[5]==0 || self->hall_tbl[6]==0)
	{
		bldc_dc_status.bldc_learnning_status = 3;//��ѧϰʧ��
	}
	else
	{
		bldc_dc_status.bldc_learnning_status = 2;//��ѧϰ�ɹ�
	}

}
/**
* @brief  save all parameters of bldc motor
* @param  void
* @note	  hall_tbl, hall_tbl_rvt, pid, poles.
* @retval None
*/
int bldc_save(motor_t* self)
{
	parameters_t para;
	for (int i = 0; i < 8; i++)
	{
		para.hall_tbl[i] = self->hall_tbl[i];
		para.hall_tbl_rt[i] = self->hall_tbl_rt[i];
	}
	para.pid = self->pid;
	para.poles = self->poles;

	if (0 != write_flash(HALL_TBL_ADDR, (uint32_t*)(&para), sizeof(para)/sizeof(uint32_t)))
	{
		print("parameter save failed!\r\n");
		return;
	}

	print("parameter saved!\r\n");
}
/**
* @brief  switch PWM to the next step according to hall table
* @param  void
* @note
* @retval None
*/
void bldc_switch(motor_t *self)
{
	uint16_t next_step = 0;
	if (self->duty > MAX_PWM_DUTY)
		self->duty = MAX_PWM_DUTY;
	else if (self->duty < 0)
		self->duty = 0;
	volatile uint16_t phase = 0;
	phase = GET_HALL_POS;
	if (motor.dir == POSITIVE)
		next_step = (self->hall_tbl[phase] % 6) + 1;
	else
	{
		next_step = (self->hall_tbl_rt[phase] % 6) + 1;
	}
#ifdef BLDC_TAG_TEST
	if ((next_step == self->hall_tbl[phase]) && (motor.fk_spd > 3))
	{
		bldc_err.err_bldc_hall = 1;
		print("hall error!\r\n");
	}
#endif
	switch (next_step)
	{
	case ONE:
		/*  AH -- BL  1-2*/
		EN_CH1N;  // 1-2
		EN_CH2N;
		DIS_CH3N;
		TIM1->CCR1 = self->duty;
		TIM1->CCR2 = 0;
		TIM1->CCR3 = 0;
		break;

	case TWO:
		/*  AH -- CL  1-3 */
		EN_CH1N;  // 1-3
		DIS_CH2N;
		EN_CH3N;
		TIM1->CCR1 = self->duty;
		TIM1->CCR2 = 0;
		TIM1->CCR3 = 0;
		break;
	case THREE:
		/*  BH -- CL  2-3 */
		DIS_CH1N;  // 2-3
		EN_CH2N;
		EN_CH3N;
		TIM1->CCR1 = 0;
		TIM1->CCR2 = self->duty;
		TIM1->CCR3 = 0;
		break;

	case FOUR:
		/*  BH -- AL  2-1 */
		EN_CH1N;  // 2-1
		EN_CH2N;
		DIS_CH3N;
		TIM1->CCR1 = 0;
		TIM1->CCR2 = self->duty;
		TIM1->CCR3 = 0;
		break;

	case FIVE:
		/*  CH -- AL  3-1 */
		EN_CH1N;  // 3-1
		DIS_CH2N;
		EN_CH3N;
		TIM1->CCR1 = 0;
		TIM1->CCR2 = 0;
		TIM1->CCR3 = self->duty;
		break;
	case SIX:
		/*  CH -- BL  3-2*/
		DIS_CH1N;  // 3-2
		EN_CH2N;
		EN_CH3N;
		TIM1->CCR1 = 0;
		TIM1->CCR2 = 0;
		TIM1->CCR3 = self->duty;
		break;
	default:
//		print("Hall error! %d\r\n", next_step);
		break;
	}
}
/**
* @brief  start motor
* @param  void
* @note   call bldc_swtich to trigger hall commutation
* @retval None
*/
void bldc_start(motor_t* self)
{
	enable_bldc(&motor);
	bldc_switch(self);
}
/**
* @brief  update motor control
* @param  void
* @note   motor spd cacualte; pid update.
* @retval None
*/
void bldc_update(motor_t* self)
{
	uint32_t time = 0;
	static int last_hall_pos = 0, hall_pos = 0, temp = 0;
	static int spd_dir = 0;
	float output = 0;
	uint8_t hall = GET_HALL_POS;
	switch (motor.ctrl_mode)
	{
	case 1:
		//if (temp == 0)   // for the first time get in
		//{
		//	temp++;
		//	last_hall_pos = self->hall_tbl[GET_HALL_POS];
		//	hall_pos = last_hall_pos;
		//}
		//for (int i = 0; i < SPD_CAL_FILTER_LEN; i++)
		//	time += self->time_stamp[i];
		//time = time * self->poles;
	
//		if (hall<1 || hall>6)
//		{
//			bldc_err.err_bldc_hall = 1;
//#ifdef BLDC_TAG_TEST
//			print("hall detect failed!\r\n");
//#endif
//		}
		//hall_pos = self->hall_tbl[hall];

		//if (hall_pos == (last_hall_pos + 1) % 6)
		//	spd_dir = 1;
		//else if (hall_pos == (last_hall_pos + 5) % 6)
		//	spd_dir = -1;

		//last_hall_pos = hall_pos;
		//if (time == 0)
		//	self->fk_spd = 0;
		//else
		//	self->fk_spd = 1000000.0 / time * spd_dir;
		//if (self->timeoutofstill > TIMEOUT_OF_STILL)
		//{
		//	self->fk_spd = 0;
		//}

// 		output = pid_update(&self->pid, self->tar_spd, self->fk_spd);
// 		if (output < 0)
// 		{
// 			self->dir = NEGATIVE;
// 			output = -output;
// 		}
// 		else
// 			self->dir = POSITIVE;
// 		motor.duty = output;
		break;
	case 2:
		if (temp == 0)   // for the first time get in
		{
			temp++;
			last_hall_pos = self->hall_tbl[GET_HALL_POS];
			hall_pos = last_hall_pos;
		}
		
		if (hall < 1 || hall>6)
		{
			print("hall detect failed!\r\n");
		}
		hall_pos = self->hall_tbl[hall];

		if (hall_pos == (last_hall_pos + 1) % 6)
			spd_dir = 1;
		else if (hall_pos == (last_hall_pos + 5) % 6)
			spd_dir = -1;
		last_hall_pos = hall_pos;
		output=self->tar_duty;
		if (output < 0)
		{
			self->dir = NEGATIVE;
			output = -output;
		}
		else
			self->dir = POSITIVE;
		motor.duty = output;
		break;
	}
		
}
/**
* @brief  load parameters of bldc_motor
* @param  void
* @note   Poles, Hall_Sequence, Pid
* @retval None
*/
void bldc_load_para(motor_t *self)
{
	parameters_t *para;
	para = (parameters_t *)HALL_TBL_ADDR;
	for (int i = 0; i < 8; i++)
	{
		self->hall_tbl[i] = para->hall_tbl[i];
		__ASM("dsb");

	}
	for (int i = 0; i < 8; i++)
	{
		self->hall_tbl_rt[i] = para->hall_tbl_rt[i];
		__ASM("dsb");

	}

	for (int i = 1; i < 7; i++)
	{
		if ((self->hall_tbl[i] > 6) || (self->hall_tbl[i] < 1))
		{
			self->err |= ERR_BLDC_HALL;
			serial.err_tx.err |= ERR_RTU_INTERNAL;
		}
		if ((self->hall_tbl_rt[i] > 6) || (self->hall_tbl_rt[i] < 1))
		{
			self->err |= ERR_BLDC_HALL;
			serial.err_tx.err |= ERR_RTU_INTERNAL;
		}
	}
#ifdef MAXON_USED
	self->hall_tbl[1] = 3;
	self->hall_tbl[2] = 1;
	self->hall_tbl[3] = 2;
	self->hall_tbl[4] = 5;
	self->hall_tbl[5] = 4;
	self->hall_tbl[6] = 6;
	self->hall_tbl_rt[1] = 6;
	self->hall_tbl_rt[2] = 4;
	self->hall_tbl_rt[3] = 5;
	self->hall_tbl_rt[4] = 2;
	self->hall_tbl_rt[5] = 1;
	self->hall_tbl_rt[6] = 3;
#else
	self->hall_tbl[1] = 2;
	self->hall_tbl[2] = 4;
	self->hall_tbl[3] = 3;
	self->hall_tbl[4] = 6;
	self->hall_tbl[5] = 1;
	self->hall_tbl[6] = 5;
	self->hall_tbl_rt[1] = 5;
	self->hall_tbl_rt[2] = 1;
	self->hall_tbl_rt[3] = 6;
	self->hall_tbl_rt[4] = 3;
	self->hall_tbl_rt[5] = 4;
	self->hall_tbl_rt[6] = 2;
#endif
	ms_sleep(10);
	//	print("******BLDC MOTOR PARAMETER LISTS******\r\n");
	print("hall_table_flash: %d %d %d %d %d %d\r\n", \
		self->hall_tbl[1], self->hall_tbl[2], self->hall_tbl[3], \
		self->hall_tbl[4], self->hall_tbl[5], self->hall_tbl[6]);
	print("hall_table_rvt: %d %d %d %d %d %d\r\n", \
		self->hall_tbl_rt[1], self->hall_tbl_rt[2], self->hall_tbl_rt[3], \
		self->hall_tbl_rt[4], self->hall_tbl_rt[5], self->hall_tbl_rt[6]);
	motor.poles = 8;
	self->poles = 8;

	print("poles = %d\r\n", self->poles);
	pid_contorller_t *pid = &self->pid;
	pid->kp = para->pid.kp;
	pid->ki = 1;
	motor.pid.ki_flash = 1;
	motor.pid.k = 10;
	pid->k = 10;
	if (para->pid.k > 1000)
	{
		motor.pid.k = 10;
	}
	if (para->pid.ki_flash > 100)
	{
		motor.pid.ki_flash = 1;
	}
	float tt = pid->kp;
	int test1 = tt * 100;
	tt = pid->ki;
	int test2 = tt * 100;
	tt = pid->k;
	int test3 = tt * 100;
	print("kp=%d  ki=%d  k=%d  uimax:%d\r\n", \
		test1, test2, test3, (int32_t)self->pid.imax);
	self->timeoutofcontrol = 500;
	motor.timeoutofoctremble = 0;
	self->ctrl_mode = 1;
	motor.motor_learning_flag = 0;
	motor.motor_learning_seq = 0;
	motor.motor_enabled_flag = 0;
	motor.motor_enabled_seq = 0;
	bldc_dc_status.bldc_learnning_status = 0;
	bldc_dc_status.bldc_enabled_status = 0;
	motor.motor_set_speed_flag = 0;
	motor.motor_set_speed_seq = 0;
	motor.motor_set_duty_flag = 0;
	motor.motor_set_duty_seq = 0;
	motor.motor_clear_err_flag = 0;
	motor.motor_clear_err_seq = 0;
	motor.bldc_sensor_state = 1;
	motor.i_bus_count_tick = 0;
	motor.i_bus_max_count_tick = 0;
	motor.i_bus_max_count_flag = 0;
	bldc_package_cnt.bldc_to_motherboard_package_cnt = 0;
	bldc_package_cnt.motherboard_to_bldc_package_cnt = 0;

	// 	self->pid.kp = 40;
	// 	self->pid.ki = 0.1;

	if (self->timeoutofoctremble > 1000)
	{
		self->timeoutofoctremble = 0;
	}
	if (self->timeoutofcontrol > 10000)
	{
		self->timeoutofcontrol = 500;
	}
	print("ctrl_mode: %d\r\n", self->ctrl_mode);
	print("timeout: %d ms\r\n", self->timeoutofcontrol);

}
void print_info(motor_t *self)
{
	print("ctrl_mode: %d\r\n", self->ctrl_mode);
	print("timeout: %u ms\r\n", self->timeoutofcontrol);
	print("\r\nhall_table: %d %d %d %d %d %d\r\n", \
		self->hall_tbl[1], self->hall_tbl[2], self->hall_tbl[3], \
		self->hall_tbl[4], self->hall_tbl[5], self->hall_tbl[6]);
	print("hall_table_rvt: %d %d %d %d %d %d\r\n", \
		self->hall_tbl_rt[1], self->hall_tbl_rt[2], self->hall_tbl_rt[3], \
		self->hall_tbl_rt[4], self->hall_tbl_rt[5], self->hall_tbl_rt[6]);
	print("poles = %d\r\n", self->poles);
	pid_contorller_t *pid = &self->pid;
	pid->kp = pid->kp;
	pid->ki = pid->ki;
	float tt = pid->kp;
	int test1 = tt * 100;
	tt = pid->ki;
	int test2 = tt * 100;
	print("kp=%d  ki=%d  uimax:%f\r\n", \
		test1, test2, self->pid.imax);
}
/**
* @brief  initialize pid_controller to default values
* @param  void
* @note   Kp = 20, Ki = 0.1
* @retval None
*/
void pid_init(pid_contorller_t * self)
{
	self->err = 0;
	self->err_err = 0;
	self->ui = 0;
	self->ud = 0;
	self->kd = 0;
	self->kp = 30;
	self->output = 0;
	self->last_output = 0;
	self->imax = MAX_PWM_DUTY;
	self->imin = -1 * MAX_PWM_DUTY;
}
void pid_reset(pid_contorller_t * self)
{
 	self->err = 0;
	motor.tar_spd = 0;
}
/**
* @brief  calculate pid and update
* @param  void
* @note   called by bldc_update()
* @retval None
*/
float pid_update(pid_contorller_t * self, float tar_spd, float fk_spd)
{
		float d_out;
		self->err = tar_spd - fk_spd;
		if (fabs(self->err) < MIN_ERR)
		{
			self->err = 0;
		}

		//if ((fabs(tar_spd)<0.0001) && (fabs(fk_spd) < 3))          //�ֶη�ֹͣ������ 
		//{
		//	self->kp = 40*sqrt(fabs(self->err));
		//	self->ki = 0.6;
		//}else
		//{
			self->kp = 10;
			self->ki = 1;
		//}
		self->err_err = self->err - self->last_err;
		self->last_err = self->err;
		self->ui += self->err;

		if (self->ui > (MAX_PWM_DUTY / self->ki))
		{
			self->ui = (MAX_PWM_DUTY / self->ki);
		}
		else if (self->ui < (-(MAX_PWM_DUTY / self->ki)))
		{
			self->ui = (-(MAX_PWM_DUTY / self->ki));
		}

		self->output = self->kp * self->err;// +self->ki * self->ui;// +self->kd * self->err_err;

		if (fabs(self->err) < 8)					//����ٶ����С��5�����PID�������
		{
			d_out = self->ki*self->ui;			    //�������
			self->output += d_out;	   				
		}
		else
		{
			self->ui = 0;
		}
#if 0
		if (fabs(self->err) >6)
		{
			if ((self->output - self->last_output) > 50)           //����ռ�ձ��������Ϊ50
			{
				self->output = self->last_output + 50;
			}
			else if ((self->last_output - self->output) > 50)
			{
				self->output = self->last_output - 50;
			}
		}
#endif

		if (self->output >= self->imax)
		{
			self->output = self->imax;
		}
		else if (self->output <= self->imin)
		{
			self->output = self->imin;
		}
		self->last_output = self->output;
	return self->output;

}


