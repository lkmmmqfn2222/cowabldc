#include "terminal.h"
#include "dc_motor.h"


volatile uint8_t cmd[CMD_BUF_LEN];

volatile command_t rx_cmd;
volatile command_t tx_cmd;
volatile datagram_t datagram;
/**
* @brief  Initialize all command info as 0.
* @param  None
* @retval None
*/
void terminal_init(command_t* self)
{
	self->pt_head = 0;
	self->pt_tail = 0;
	memset(self->data, 0, CMD_BUF_LEN);
	self->len = 0;
	datagram.cmd = 0;
	datagram.data = 0;
	datagram.sign_data = 1;
	datagram.state = 0;
}
/**
* @brief  Get data from command buf and decode.
* @param  
*		v -- data: velocity set
*       d -- data: duty	 set
*		i -- 10:   motor commutation identify
*       s -- 10:   parameter save
*       e -- 1:    enable  e -- 2: disable
*		r -- 1:    read hall table 2: reboot
*		c -- data  change direction
*		x -- Pi, y -- Ki
*		p -- print Kp, Ki, v, duty, 
* @retval None
*/
void terminal_run(command_t* self)
{
#if 0
	RS_485_RD;
	ms_sleep(RS_485_DEALY);
	uint8_t temp = 0;
	if (self->pt_head != self->pt_tail )
	{
		//self->len--;
		temp = self->data[self->pt_head++];
		self->pt_head %= CMD_BUF_LEN;

		if ((datagram.state == 0x01) && ((temp >= '0') && (temp <= '9') || (temp=='-')))
		{
			if (temp != '-')
			{
				datagram.data = datagram.data * 10 + (temp - 0x30) * datagram.sign_data;
			}
			else
			{
				datagram.sign_data = -1;
			}
			
			//datagram.state |= 0x02;
		}
		else if ((datagram.state == 0) && (temp >= 'a') && (temp <= 'z'))
		{
			datagram.cmd = temp;
			datagram.state |= 0x01;
		}
		else if ((datagram.state == 0x01 || datagram.state == 5) && (temp == '\r' || temp == '\n'))
		{
			datagram.state |= 0x04;
		}
		else if (temp == ' ')
		{
		}
		else if ((temp == '\n') && (datagram.state == 0))
		{
			RS_485_WR;
			ms_sleep(RS_485_DEALY);
			print("[BLDC]:\r\n");
		}
		else
			datagram.state = 0;

		if (datagram.state == 5)
		{
			RS_485_WR;
			ms_sleep(RS_485_DEALY);
			if (datagram.cmd == 'v')			// v
			{

				motor.tar_spd = datagram.data / 10.0;
#if 1
				print("v\r\nv = %d.%d fk = %d.%d duty = %d%%\r\n", \
					(int)motor.tar_spd, ((int)fabs(motor.tar_spd) * 100) % 100, \
					(int)motor.fk_spd, ((int)fabs(motor.fk_spd * 100) % 100), \
					(int)(motor.duty * 1.0 / MAX_PWM_DUTY * 100));
#endif
			}
			else if (datagram.cmd == 'd')		// d
			{
				if (datagram.data > 100)
				{
					datagram.data = 100;
				}
				motor.duty = datagram.data / 100.0 * MAX_PWM_DUTY;
				print("d\r\nd = %d%% pwm = %d/%d\r\n", datagram.data, motor.duty, (uint16_t)(MAX_PWM_DUTY));
			}
			else if (datagram.cmd == 'i' && datagram.data == 10)  // i
			{
				print("i\r\nhall sequence detecting...\r\n");
				bldc_com_identify(&motor);
			}
			else if (datagram.cmd == 's' && datagram.data == 10)	// s
			{
				motor.enabled = 0;
				parameters_t para;
				for (int i = 0; i < 8;i++)
				{
					para.hall_tbl[i] = motor.hall_tbl[i];
					para.hall_tbl_rt[i] = motor.hall_tbl_rt[i];
				}
				para.poles = motor.poles;
				para.pid = motor.pid;
				if (0 != write_flash(HALL_TBL_ADDR, (&para), sizeof(para) / sizeof(uint32_t)))
				{
					print("s\r\nparameter save failed!\r\n");
				}
				else
				{
					print("s\r\nparameters saved!\r\n");
				}
			}
			else if (datagram.cmd == 'e')		// e
			{
				print("e\r\n");
				if (datagram.data == 1)
				{
					enable_bldc(&motor);
					bldc_start(&motor);
					print("bldc enabled!\r\n");
				}
				else
				{
					motor.tar_spd = 0;
					ms_sleep(1000);
					disable_bldc(&motor);

					print("bldc disabled!\r\n");
				}
			}
			else if (datagram.cmd == 'r')		// r
			{
				disable_bldc(&motor);
				if (datagram.data == 1)
				{
					parameters_t *para;
					para = (parameters_t *)HALL_TBL_ADDR;
					
					for (int i = 0; i < 8;i++)
					{
						motor.hall_tbl[i] = para->hall_tbl[i];
					}
					for (int i = 0; i < 8; i++)
					{
						motor.hall_tbl_rt[i] = para->hall_tbl_rt[i];
					}
	
					RS_485_WR;
					ms_sleep(10);
					print("r\r\nhall_table: %d %d %d %d %d %d\r\n", \
						motor.hall_tbl[1], motor.hall_tbl[2], motor.hall_tbl[3], \
						motor.hall_tbl[4], motor.hall_tbl[5], motor.hall_tbl[6]);
					print("hall_table_rvt: %d %d %d %d %d %d\r\n", \
						motor.hall_tbl_rt[1], motor.hall_tbl_rt[2], motor.hall_tbl_rt[3], \
						motor.hall_tbl_rt[4], motor.hall_tbl_rt[5], motor.hall_tbl_rt[6]);

					motor.poles = para->poles;
					motor.pid = para->pid;
					print("poles = %d\r\n", motor.poles);
					pid_contorller_t *pid = &motor.pid;
					pid->kp = pid->kp;
					pid->ki = pid->ki;
					float tt = pid->kp;
					int test1 = tt * 100;
					tt = pid->ki;
					int test2 = tt * 100;
					print("kp=%d  ki=%d\r\n", \
						test1, test2);
				}
				else if (datagram.data == 2)
				{
					NVIC_SystemReset();
				}
			}
			else if (datagram.cmd == 'c')	//
			{
				print("c\r\n");
				if (datagram.data == 1)
				{
					motor.dir = POSITIVE;
					print("POSITIVE\r\n");
				}
				else
				{
					motor.dir = NEGATIVE;
					print("NEGATIVE\r\n");
				}
			}
			else if (datagram.cmd == 't')
			{
				//print("t\r\ntest begin....\r\n");
				disable_bldc(&motor);
				motor.tar_spd = 0;
				enable_bldc(&motor);
				motor.tar_spd = datagram.data / 10.0;
				bldc_start(&motor);
				motor.status = TEST;
				
				while (motor.cnt < 1024);
				motor.status = NORMAL;
				motor.tar_spd = 0;
				pid_reset(&motor.pid);
				ms_sleep(1000);
				disable_bldc(&motor);
				motor.cnt = 0;
				for (int i = 0; i < 1024; i++)
				{
					print("%d\r\n", motor.fk_spd_buf[i]);
				}
			}
			else if (datagram.cmd == 'x')
			{
				disable_bldc(&motor);
				pid_contorller_t *pid = &motor.pid;
				pid->kp = pid->kp;
				pid->kp = datagram.data / 100.0;
				float tt = pid->kp;
				int test = tt*100;
				print("x\r\nkp = %d\r\n", test);
			}
			else if (datagram.cmd == 'y')
			{
				disable_bldc(&motor);
				pid_contorller_t *pid = &motor.pid;
				pid->ki = pid->ki;
				pid->ki = datagram.data / 100.0;
				float tt = pid->ki;
				int test = tt * 100;
				print("y\r\nki = %d\r\n", test);
			}
			else if (datagram.cmd == 'z')
			{
				motor.poles = datagram.data;
				print("z\r\npoles = %d\r\n", motor.poles);
			}
			else if (datagram.cmd == 'p')
			{
				//print("p\r\nv=%.2f fk=%.2f duty=%.2f\r\n", \
					//motor.tar_spd, motor.fk_spd, motor.duty * 1.0 / MAX_PWM_DUTY);
				print("duty: %d\r\n", motor.duty);
				pid_contorller_t *pid = &motor.pid;
				pid->kp = pid->kp;
				pid->ki = pid->ki;
				float tt = pid->kp;
				int test1 = tt * 100;
				tt = pid->ki;
				int test2 = tt * 100;
				print("kp=%d.%d  ki=%d.%d\r\n", \
					test1 / 100, test1 % 100,\
					test2 / 100, test2 % 100);
#if 0
				for (int i = 0; i < 128;i++)
				{
					if (buf[i] == '\0')
					{
						break;
					}
					USART_SendData(USART1, buf[i]);
					while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
				}
#endif
				
			}
			else if (datagram.cmd == 'l')
			{
				if (datagram.data == 1)
				{
					dc_run(DC_DIR_POSITIVE);
					print("lock\r\n");
				}
				else if (datagram.data == 2)
				{
					dc_run(DC_DIR_NEGATIVE);
					print("unlock");
				}
				else
				{
					dc_stop();
					print("hold\r\n");
				}
					
			}
			datagram.data = 0;
			datagram.state = 0;
			datagram.sign_data = 1;
			print("\r\n");
		}
// 		if (*self->pt_head == '\0')
// 		{
// 			self->pt_head++;
// 			if (self->pt_head > self->data + CMD_BUF_LEN)
// 			{
// 				self->pt_head -= CMD_BUF_LEN;
// 			}
// 			self->len--;
// 		}
// 		if (strcmp(self->pt_head, "duty") == 0)
// 		{
// 			self->len -= 4;
// 			self->pt_head += 4;
// 			if (self->pt_head > self->data + CMD_BUF_LEN)
// 			{
// 				self->pt_head -= CMD_BUF_LEN;
// 			}
// 			print("duty enter\r\n");
// 		}
// 		else if (strcmp(self->pt_head, "spd") == 0)
// 		{
// 			self->len -= 3;
// 			self->pt_head += 3;
// 			if (self->pt_head > self->data + CMD_BUF_LEN)
// 			{
// 				self->pt_head -= CMD_BUF_LEN;
// 			}
// 			print("spd enter\r\n");

// 		}
	}
#endif
}
/**
* @brief  data exchange and decode test.
* @param  None
* @retval None
*/
void terminal_test(datagram_t* self)
{
	uint8_t temp = 0;

	if ((datagram.state == 0x01) && (temp >= '0') && (temp <= '9'))
	{
		datagram.data = datagram.data * 10 + temp - 0x30;
		//datagram.state |= 0x02;
	}
	else if ((datagram.state == 0) && (temp >= 'a') && (temp <= 'z'))
	{
		datagram.cmd = temp;
		datagram.state |= 0x01;
	}
	else if ((datagram.state == 0x01 || datagram.state == 5) && (temp == '\r' || temp == '\n'))
	{
		datagram.state |= 0x04;
	}
	else
		datagram.state = 0;

	if (self->state == 5)
	{
		if (self->cmd == 's')
		{
			self->state = 0;
			print("s %d\r\n", self->data);
			self->data = 0;
		}
		else if (self->cmd == 'd')
		{
			self->state = 0;
			print("d %d\r\n", self->data);
			self->data = 0;
		}
	}
}