#ifndef __TERMINAL_H__
#define __TERMINAL_H__

#include "stm32f0xx_conf.h"
#include "string.h"
#include "bldc.h"
#include "math.h"
#define  CMD_BUF_LEN	64
#define  RS_485_DEALY	1
volatile uint8_t cmd[CMD_BUF_LEN];

typedef struct
{
	uint8_t cmd;
	int16_t data;
	uint8_t state;
	int8_t  sign_data;
}datagram_t;

typedef  struct
{
	uint8_t pt_head;
	uint8_t pt_tail;
	uint8_t  data[CMD_BUF_LEN];
	uint8_t  len;
}command_t;
volatile command_t rx_cmd;
volatile command_t tx_cmd;

volatile datagram_t datagram;
/**
* @brief  Initialize all command info as 0.
* @param  None
* @retval None
*/
void terminal_init(command_t* self);
/**
* @brief  Get data from command buf and decode.
* @param  None
* @retval None
*/
void terminal_run(command_t* self);
/**
* @brief  data exchange and decode test.
* @param  None
* @retval None
*/
void terminal_test(datagram_t* self);
#endif // !__TERMINAL_H__
