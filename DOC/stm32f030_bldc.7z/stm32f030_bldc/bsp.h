#ifndef  __BSP_H__
#define  __BSP_H__

#include "stm32f0xx_conf.h"
#include "version.h"
#include "stdint-gcc.h"

#define  SERIAL_BUF_LEN		8
#define  CIRCUL_BUF_LEN		600

#define  HALL_TIM3_IRQ_PRIORITY			0x01
#define  PWM_TIM1_COM_PRIORITY			0x02 
#define  USART1_IRQ_PRIORITY			0x00
#define  SERIAL_TIM14_PRIORITY			0x03
#define  DC_MOTOR_OVERCUR_PRIORITY		0x04
#define  DC_MOTOR_POSARRIVE_PRIORITY	0x05

#define  I_BUS_ADC		0
#define  WHEEL_ANGLE_ADC     1
#define  I_BUS_TREMBLE     1600
#define  I_BUS_MAX_TREMBLE     1800

volatile char command[];
volatile uint16_t ms_timer;
void ms_sleep(uint16_t time);

int write_flash(uint32_t addr, uint32_t* data, uint32_t len);

void init_drv(void);
void hall_tim3_config(void);
void pwm_tim1_config(void);
void usart1_config(void);
void dma_handler(void);
void adc_config(void);
void watchdog_init(void);
void SysTickConfig(void);
void fft_test(void);

#endif
