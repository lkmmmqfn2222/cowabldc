#!/usr/bin/env python
import os, sys, time, subprocess  

DIRS = [r'C:\"Program Files (x86)"\Git\bin', r'C:\"Program Files"\Git\bin', \
		r'D:\"Program Files (x86)"\Git\bin', r'D:\"Program Files"\Git\bin' ]

DIR = None
for dir in DIRS:
    if os.path.exists(dir.replace('"','') + '\\git.exe' ):
        DIR = dir
        break
if DIR == None:
    print 'no git found'
    sys.exit(-1)
try:
    p1 = subprocess.Popen('"%s\\git.exe" log --oneline'%(DIR.replace('"',"")), stdout=subprocess.PIPE)  
    p2 = subprocess.Popen('"%s\\git.exe" describe --tags --long'%(DIR.replace('"',"")), stdout=subprocess.PIPE) 
    time.sleep(1) 

    rev = len(p1.stdout.read().split('\n'))
    ver = p2.stdout.read().replace('-', '.').split('.')[0:-1]
    for i in range(0, len(ver)): ver[i] = int(ver[i].replace('V', ''))
    ver.append(rev)
    print "V%s.%s.%s.%s"%(ver[0], ver[1], ver[2], ver[3])
except:
    ver = [0, 0, 0, 0]
    print "V%s.%s.%s.%s"%(ver[0], ver[1], ver[2], ver[3])

if len(sys.argv) >= 2:
    FILE = sys.argv[1]

    file = open(FILE, 'w')
    print >>file, '''#ifndef __VERSION_H__\n#define __VERSION_H__'''
    print >>file, '''#define VERSION(a,b,c) (((a) << 24) + ((b) << 16) + (c))''' 
    print >>file, '''#define MAJOR_VERSION %d'''%ver[0]
    print >>file, '''#define MINOR_VERSION %d'''%ver[1]
    print >>file, '''#define REVISED_VERSION %d'''%ver[2]
    print >>file, '''#define BUILD_VERSION %d'''%ver[3]
    print >>file, '''#define VERSION_NO VERSION(MAJOR_VERSION, MINOR_VERSION, REVISED_VERSION)'''
    print >>file, '''#define VERSION_STR "V%s.%s.%s.%s"'''%(ver[0], ver[1], ver[2], ver[3])
    print >>file, '''#endif'''
    file.close()
