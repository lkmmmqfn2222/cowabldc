#include "dc_motor.h"
#include "bsp.h"
#include "bldc.h"
#include "newprotocol.h"

volatile dc_motor_t dc_motor;

/**
* @brief  configure all resources which is need for dc_motor
* @param  void
* @note   PA0: Position1 interrupt   poll check
*		  PA1: Position2 interrupt   poll check
*		  PA2: m_ctrl2  --  TIM15_CH1
*		  PA3: m_ctrl1  --  TIM15_CH2
*         PA4: over_current detection, Low is active
* @retval None
*/
void dc_motor_init(void)
{
	EXTI_InitTypeDef   EXTI_InitStructure;
	GPIO_InitTypeDef   GPIO_InitStructure;
	NVIC_InitTypeDef   NVIC_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;

	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM15, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_PinAFConfig(GPIOA, GPIO_PinSource11, GPIO_AF_0);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_0);

	TIM_DeInit(TIM15);
	TIM_TimeBaseStructure.TIM_Prescaler = 47;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseStructure.TIM_Period = 50;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM15, &TIM_TimeBaseStructure);

	/* Channel 1, 2,3 and 4 Configuration in PWM mode */
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Disable;
	TIM_OCInitStructure.TIM_Pulse = 0;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCNPolarity_High;
	TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High;
	TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Reset;
	TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Set;

	TIM_OC1Init(TIM15, &TIM_OCInitStructure);
	TIM_OC2Init(TIM15, &TIM_OCInitStructure);

	TIM15->CCR1 = 0;
	TIM15->CCR2 = 0;
	TIM_CtrlPWMOutputs(TIM15, ENABLE);

	TIM_Cmd(TIM15, ENABLE);

	/* Configure PA0, PA1 pin as input floating */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_5 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	dc_motor.over_current_time = 0;
	dc_motor.pos1_arrive_time = 0;
	dc_motor.pos2_arrive_time = 0;
	dc_motor.pos3_arrive_time = 0;
	dc_motor.pos_from_start = 0;
	dc_motor.dc_motor_wheel_state_flag = 0;
	dc_motor.dc_motor_wheel_state_seq = 0;
	dc_motor.dc_motor_second_gear_flag = 0;
	dc_motor.dc_motor_second_gear_start = 0;
	dc_motor_para_t dc_para;
	dc_para = *(dc_motor_para_t*)(DC_MOTOR_PARA_ADDR);

	if (dc_para.set_duty_step != 2)
	{
		dc_para.set_duty_step = 2;
	}
	if (dc_para.set_max_pwm >= 90)
	{
		dc_para.set_max_pwm = 90;
	}
	if (dc_para.set_oc_tremble_timeout != 100)
	{
		dc_para.set_oc_tremble_timeout = 100;
	}
	if (dc_para.set_pos_tremble_timeout != 100)
	{
		dc_para. set_pos_tremble_timeout = 100;
	}
	if (dc_para.set_updown_timeout != 4000)
	{
		dc_para.set_updown_timeout = 4000;
	}
	dc_motor.wheel_angle_studied_flag = 0;
	dc_para.wheel_up_angle_value = 0;
	dc_para.wheel_down_angle_value = 0;
	dc_motor.para = dc_para;
	dc_motor.dc_motor_liftup_state = FALSE;
	dc_motor.dc_motor_liftdown_state = FALSE;
}

//����������ѹ������
pid_contorller_dc_motor_t pid_dc_motor;
void dc_motor_right_position_update(uint16_t duty)
{
	static int make_sure_cnt;
	float d_out_dc_motor;
	if (fabs(adc_dma[WHEEL_ANGLE_ADC] - (dc_motor.wheel_down_angle_value + duty)) < 300)
	{
		pid_dc_motor.err = (dc_motor.wheel_down_angle_value + duty) - adc_dma[WHEEL_ANGLE_ADC];
		if (fabs(pid_dc_motor.err) < 10)
		{
			pid_dc_motor.err = 0;
		}
		pid_dc_motor.kp = 1;
		//pid_dc_motor.ki = 0.1;
		//pid_dc_motor.ui += pid_dc_motor.err;
		//if (pid_dc_motor.ui > (MAX_PWM_DUTY / pid_dc_motor.ki))
		//{
		//	pid_dc_motor.ui = (MAX_PWM_DUTY / pid_dc_motor.ki);
		//}
		//else if (pid_dc_motor.ui < (-(MAX_PWM_DUTY / pid_dc_motor.ki)))
		//{
		//	pid_dc_motor.ui = (-(MAX_PWM_DUTY / pid_dc_motor.ki));
		//}
		pid_dc_motor.output = pid_dc_motor.kp * pid_dc_motor.err;// +pid_dc_motor.ki * pid_dc_motor.ui;
		if (pid_dc_motor.output >= 99)
		{
			pid_dc_motor.output = 99;
		}
		else if (pid_dc_motor.output <= (-99))
		{
			pid_dc_motor.output = (-99);
		}
		if (pid_dc_motor.output >= 0)
		{
			TIM15->CCR1 = 0;
			TIM15->CCR2 = pid_dc_motor.output;
		}
		else if (pid_dc_motor.output < 0)
		{
			TIM15->CCR1 = (0 - pid_dc_motor.output);
			TIM15->CCR2 = 0;
		}
		if (fabs(pid_dc_motor.err) < 15)
		{
			make_sure_cnt++;
			if (make_sure_cnt>600)
			{
				dc_motor.dc_motor_second_gear_start = 0;
				bldc_dc_status.dc_wheel_status = 4;
				dc_motor.pos1_arrive_time = 0;
				dc_motor.pos_from_start = 0;
				make_sure_cnt = 0;
			}
		}
		else
		{
			make_sure_cnt = 0;
		}
	}
}

//����������ѹ������
void dc_motor_left_position_update(uint16_t duty)
{
	static int make_sure_cnt_left;
	float d_out_dc_motor;
	if (fabs(adc_dma[WHEEL_ANGLE_ADC] - (dc_motor.wheel_down_angle_value - duty)) < 300)
	{
		pid_dc_motor.err = (dc_motor.wheel_down_angle_value - duty) - adc_dma[WHEEL_ANGLE_ADC];
		if (fabs(pid_dc_motor.err) < 10)
		{
			pid_dc_motor.err = 0;
		}
		pid_dc_motor.kp = 1;
		//pid_dc_motor.ki = 0.1;
		//pid_dc_motor.ui += pid_dc_motor.err;
		//if (pid_dc_motor.ui > (MAX_PWM_DUTY / pid_dc_motor.ki))
		//{
		//	pid_dc_motor.ui = (MAX_PWM_DUTY / pid_dc_motor.ki);
		//}
		//else if (pid_dc_motor.ui < (-(MAX_PWM_DUTY / pid_dc_motor.ki)))
		//{
		//	pid_dc_motor.ui = (-(MAX_PWM_DUTY / pid_dc_motor.ki));
		//}
		pid_dc_motor.output = pid_dc_motor.kp * pid_dc_motor.err;// +pid_dc_motor.ki * pid_dc_motor.ui;
		if (pid_dc_motor.output >= 99)
		{
			pid_dc_motor.output = 99;
		}
		else if (pid_dc_motor.output <= (-99))
		{
			pid_dc_motor.output = (-99);
		}
		if (pid_dc_motor.output >= 0)
		{
			TIM15->CCR1 = pid_dc_motor.output;
			TIM15->CCR2 = 0;
		}
		else if (pid_dc_motor.output < 0)
		{
			TIM15->CCR1 = 0;
			TIM15->CCR2 = (0 - pid_dc_motor.output);
		}
		if (fabs(pid_dc_motor.err) < 15)
		{
			make_sure_cnt_left++;
			if (make_sure_cnt_left > 600)
			{
				dc_motor.dc_motor_second_gear_start = 0;
				bldc_dc_status.dc_wheel_status = 4;
				dc_motor.pos1_arrive_time = 0;
				dc_motor.pos_from_start = 0;
				make_sure_cnt_left = 0;
			}
		}
		else
		{
			make_sure_cnt_left = 0;
		}
	}
}
