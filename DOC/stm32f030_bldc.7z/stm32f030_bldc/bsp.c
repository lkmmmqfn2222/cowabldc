#include "bsp.h"
#include "bldc.h"
#include "newprotocol.h"
#include "stm32f0xx_dma.h"
volatile uint16_t ms_timer = 0;
volatile char command[64];

void ms_sleep(uint16_t time)
{
	ms_timer = time;
	while (ms_timer){ continue; };
}
/**
* @brief  setup L6230
* @param  void
* @note   PB11--- DIAG_EN, input to detect L6230 status. H: normal; L: fault
*		  PA11--- CPOUT1,  input, over current detection.
*		  PA4 --- BLDC_PWM, output, over current reference.
*		  PB8 --- POWER_ON H:power_on; L:power_off
*		  PF7 --- POWER_ON H:power_on; L:power_off 
*	Caution: When power on L6230, pull PF7 to high first, than pull on PB8
* @retval None
*/
void init_drv(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB | RCC_AHBPeriph_GPIOC | RCC_AHBPeriph_GPIOA | RCC_AHBPeriph_GPIOF, ENABLE);
	/* Configure PC13,PB9,PB8,PB3,PF7,PA12 pin as input floating */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOF, &GPIO_InitStructure);	
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

/*
*  TIM3: Hall detection.
*  Poles = 4, 4 * 6 = 24, 24*50=1200, 1 /1200 = 0.0008
*  PB4 --- CH1
*  PB5 --- CH2
*  PB0 --- CH3
*  TIM_BASE: 100K, 0.01ms * 65536 = 655.36ms
*  MAX_SPD: 100K / (Poles * 6) = 4K rps, MIN_SPD: 1 / (0.65536s * 24) =  0.06 rps
*/
#define TIM3_CLK_IN		1000000
void hall_tim3_config(void)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;             
	TIM_ICInitTypeDef  TIM_ICInitStructure;                     
	NVIC_InitTypeDef NVIC_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;
	uint16_t PrescalerValue = (uint16_t)((SystemCoreClock) / TIM3_CLK_IN) - 1;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_4 | GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_PinAFConfig(GPIOB, GPIO_PinSource0, GPIO_AF_1);
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource4, GPIO_AF_1);
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource5, GPIO_AF_1);

	TIM_DeInit(TIM3);

	TIM_TimeBaseStructure.TIM_Prescaler = PrescalerValue;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; 
	TIM_TimeBaseStructure.TIM_Period = 65535;											
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;					
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

	TIM_SelectHallSensor(TIM3, ENABLE);
	TIM_SelectInputTrigger(TIM3, TIM_TS_TI1F_ED);
	TIM_SelectSlaveMode(TIM3, TIM_SlaveMode_Reset);
	TIM_SelectMasterSlaveMode(TIM3, TIM_MasterSlaveMode_Enable);

	TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;            	
	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_BothEdge;
	TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_TRC;
	TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;       	
	TIM_ICInitStructure.TIM_ICFilter = 0xf;         			
	TIM_ICInit(TIM3, &TIM_ICInitStructure); 
	TIM_ClearFlag(TIM3, TIM_FLAG_CC1);
	

	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Disable;
	TIM_OCInitStructure.TIM_Pulse = 1;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OC2Init(TIM3, &TIM_OCInitStructure);

	TIM_ClearFlag(TIM3, TIM_FLAG_CC2);
	TIM_SelectOutputTrigger(TIM3, TIM_TRGOSource_OC2Ref);
	TIM_ITConfig(TIM3, TIM_IT_CC1, ENABLE);

	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPriority = HALL_TIM3_IRQ_PRIORITY;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	TIM_Cmd(TIM3, ENABLE);
}
/* 1s timeout */
void watchdog_init()
{
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
	//40K/128 = 312.5(3.2ms)   
	IWDG_SetPrescaler(IWDG_Prescaler_128);
	IWDG_SetReload(313);
	IWDG_ReloadCounter();
	IWDG_Enable();
}
void adc_config(void)
{
	ADC_DeInit(ADC1);
	ADC_InitTypeDef     ADC_InitStructure;
	GPIO_InitTypeDef    GPIO_InitStructure;
	DMA_InitTypeDef     DMA_InitStructure;
	/* ADC1 DeInit */
	ADC_DeInit(ADC1);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

	/* Configure ADC Channel6 as analog input */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	/* Configure ADC Channel0 as analog input */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
	// 	����DMA,RDR�Ĵ�����д.
	DMA_DeInit(DMA1_Channel1);
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&ADC1->DR); //����Ĵ�����ַ
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)(&adc_dma);//���ջ�����
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;//�ڴ���ΪĿ���ַ
	DMA_InitStructure.DMA_BufferSize = 2;//�����С
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;//�����ַ����
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//Դ��ַ����
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;//ÿ�η��Ͷ���Byte
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;//�ֽ�
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;//ѭ������
	DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;//�е����ȼ�
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;//�����ڴ浽�ڴ洫��
	DMA_Init(DMA1_Channel1, &DMA_InitStructure);//��ʼ��
	ADC_DMARequestModeConfig(ADC1, ADC_DMAMode_Circular);// ʹ��DMA ADC1����

	/* Initialize ADC structure */
	ADC_StructInit(&ADC_InitStructure);

	/* Configure the ADC1 in continuous mode withe a resolution equal to 12 bits  */
	ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
	ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_ScanDirection = ADC_ScanDirection_Upward;
	ADC_Init(ADC1, &ADC_InitStructure);

	ADC_ChannelConfig(ADC1, ADC_Channel_0, ADC_SampleTime_13_5Cycles);
	ADC_ChannelConfig(ADC1, ADC_Channel_6, ADC_SampleTime_13_5Cycles);
	
	/* ADC Calibration */
	ADC_GetCalibrationFactor(ADC1);
	DMA_Cmd(DMA1_Channel1, ENABLE);
	ADC_DMACmd(ADC1, ENABLE);
	ADC_Cmd(ADC1, ENABLE);
		
	/* Wait the ADRDY flag */
	while (!ADC_GetFlagStatus(ADC1, ADC_FLAG_ADRDY));

	/* ADC1 regular Software Start Conv */
	ADC_StartOfConversion(ADC1);
}

/*
*	TIM1_BKIN   ---- PB12
*	TIM1_CH1N   ---- PB13
*	TIM1_CH2N   ---- PB14
*	TIM1_CH3N   ---- PB15
*	TIM1_CH1    ---- PA8
*	TIM1_CH2    ---- PA9
*	TIM1_CH3    ---- PA10
*   TIM1_CLK: 48MHz  PWM_Freq: 10k  Period:4800
*/
void pwm_tim1_config(void)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	TIM_BDTRInitTypeDef TIM_BDTRInitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	/* GPIOA and GPIOB clocks enable */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA | RCC_AHBPeriph_GPIOB, ENABLE);

	/* TIM1 clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);

	/* GPIOA Configuration: Channel 1, 2, and 3 as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_8 | GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	/* GPIOB Configuration: Channel 1N 2N and 3N as GPIO output */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	/* Connect TIM pins to AF2 */
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource8, GPIO_AF_2);	// CH1
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_2);	// CH2
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_2);	// CH3
	GPIO_ResetBits(GPIOB, GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15);

	/* Time Base configuration */
	TIM_TimeBaseStructure.TIM_Prescaler = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Down;
	TIM_TimeBaseStructure.TIM_Period = 2399;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;

	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);

	/* Channel 1, 2,3 and 4 Configuration in PWM mode */
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Disable;
	TIM_OCInitStructure.TIM_Pulse = 0;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCNPolarity_High;
	TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High;
	TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Reset;
	TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Set;

	TIM_OC1Init(TIM1, &TIM_OCInitStructure);
	TIM_OC2Init(TIM1, &TIM_OCInitStructure);
	TIM_OC3Init(TIM1, &TIM_OCInitStructure);

	/* Automatic Output enable, Break, dead time and lock configuration*/
	TIM_BDTRInitStructure.TIM_OSSRState = TIM_OSSRState_Enable;
	TIM_BDTRInitStructure.TIM_OSSIState = TIM_OSSIState_Enable;
	TIM_BDTRInitStructure.TIM_LOCKLevel = TIM_LOCKLevel_OFF;
	TIM_BDTRInitStructure.TIM_DeadTime = 1;
	TIM_BDTRInitStructure.TIM_Break = TIM_Break_Disable;
	TIM_BDTRInitStructure.TIM_BreakPolarity = TIM_BreakPolarity_High;
	TIM_BDTRInitStructure.TIM_AutomaticOutput = TIM_AutomaticOutput_Enable;
	TIM_BDTRConfig(TIM1, &TIM_BDTRInitStructure);

	TIM_CCPreloadControl(TIM1, ENABLE);
	TIM_SelectCOM(TIM1, ENABLE);
	TIM_SelectInputTrigger(TIM1, TIM_TS_ITR2);
	TIM_ITConfig(TIM1, TIM_IT_COM, ENABLE);

	DIS_CH1N;  // 1-2
	DIS_CH1N;
	DIS_CH3N;
	TIM1->CCR1 = 0;
	TIM1->CCR2 = 0;
	TIM1->CCR3 = 0;
	/* TIM1 counter enable */
	//TIM_Cmd(TIM1, ENABLE);
	/* Main Output Enable */
	TIM_CtrlPWMOutputs(TIM1, ENABLE);
	/* Enable the TIM1 Trigger and commutation interrupt */
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_BRK_UP_TRG_COM_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPriority = PWM_TIM1_COM_PRIORITY;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	TIM_Cmd(TIM1, ENABLE);
}
/*
USART1_TX ---- PB6
USART1_RX ---- PB7
GPIOx --- OE/RE - PB9
*/
void usart1_config(void)
{
	USART_InitTypeDef USART_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;
	DMA_InitTypeDef DMA_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;

	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_0);	//	TX
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_0);	//	RX

	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

	USART_Init(USART1, &USART_InitStructure);
	USART_Cmd(USART1, ENABLE);

	// 	����DMA,TDR�Ĵ�����д.
	DMA_DeInit(DMA1_Channel2);
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&USART1->TDR); //����Ĵ�����ַ
	//DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)SRC_Const_Buffer;//�����ͻ�����
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;//������ΪĿ���ַ
	DMA_InitStructure.DMA_BufferSize = 0;//�����С
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;//�����ַ����
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//Դ��ַ����
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;//ÿ�η��Ͷ���Byte
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;//�ֽ�
	DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;//���δ���
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;//�е����ȼ�
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;//�����ڴ浽�ڴ洫��
	DMA_Init(DMA1_Channel2, &DMA_InitStructure);//��ʼ��

    // ʹ��DMA USART����
	USART_DMACmd(USART1, USART_DMAReq_Tx, ENABLE);
	DMA_Cmd(DMA1_Channel2, DISABLE);

	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
	// 	����DMA,RDR�Ĵ�����д.
	DMA_DeInit(DMA1_Channel3);
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&USART1->RDR); //����Ĵ�����ַ
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)(&receive_dma);//�����ͻ�����
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;//�ڴ���ΪĿ���ַ
	DMA_InitStructure.DMA_BufferSize = CIRCUL_BUF_LEN;//�����С
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;//�����ַ����
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//Դ��ַ����
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;//ÿ�η��Ͷ���Byte
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;//�ֽ�
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;//ѭ������
	DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;//�е����ȼ�
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;//�����ڴ浽�ڴ洫��
	DMA_Init(DMA1_Channel3, &DMA_InitStructure);//��ʼ��

	// ʹ��DMA USART����
	USART_DMACmd(USART1, USART_DMAReq_Rx, ENABLE);
	DMA_Cmd(DMA1_Channel3, ENABLE);
}
int write_flash(uint32_t addr, uint32_t* wdata, uint32_t len)
{
	
	uint32_t rdata;
	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPERR);
	FLASH_ErasePage(addr);
	for (int i = 0; i < len;i++)
	{
		FLASH_ProgramWord(addr + i*4, wdata[i]);
	}
	for (int i = 0; i < len;i++)
	{
		rdata = *(__IO uint32_t *)(addr + i * 4);
		if (rdata == wdata[i])
			continue;
		else
		{
			FLASH_Lock();
			return -1;
		}
	}
	FLASH_Lock();
	return 0;
}
void tim14_serialtimout_init()
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	/* TIM14 clock enable */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM14, ENABLE);
	TIM_TimeBaseStructure.TIM_Prescaler = 23;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseStructure.TIM_Period = 1999;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM14, &TIM_TimeBaseStructure);

	TIM_ITConfig(TIM14, TIM_IT_Update, ENABLE);

	NVIC_InitStructure.NVIC_IRQChannel = TIM14_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	serial.system_timeseq = 0;       //ʱ���
	TIM_Cmd(TIM14, ENABLE);
}
/* 1ms interrupt */
void SysTickConfig(void)
{
	/* Enable SYSCFG clock */
	/* Setup SysTick Timer for 1 msec interrupts  */
	if (SysTick_Config((SystemCoreClock) / (1000 / CONTROL_PERIOD)))
	{
		/* Capture error */
		while (1);
	}

	NVIC_SetPriority(SysTick_IRQn, 0xff);
}
