#ifndef __VERSION_H__
#define __VERSION_H__
#define VERSION(a,b,c) (((a) << 24) + ((b) << 16) + (c))
#define MAJOR_VERSION 0
#define MINOR_VERSION 0
#define REVISED_VERSION 0
#define BUILD_VERSION 0
#define VERSION_NO VERSION(MAJOR_VERSION, MINOR_VERSION, REVISED_VERSION)
#define VERSION_STR "V0.0.0.0"
#endif
