#ifndef __DC_MOTOR_H__
#define __DC_MOTOR_H__

#include "stm32f0xx_conf.h"

#define		DC_MOTOR_PARA_ADDR		0x0800f400

typedef enum{DC_DIR_POSITIVE=0, DC_DIR_NEGATIVE}dc_dir_t;
#define		GET_POS1_ARRIVE		GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_15)
#define		GET_POS2_ARRIVE		GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_11)
#define		GET_POS3_ARRIVE		GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5)
#define     GET_MC_NOT_OC	    GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4)

#define		GET_HALL1_STATUS		GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13)
#define		GET_HALL2_STATUS		GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9)
#define		GET_HALL3_STATUS		GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8)
#define		GET_HALL4_STATUS		GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_3)
#define		GET_HALL5_STATUS		GPIO_ReadInputDataBit(GPIOF, GPIO_Pin_7)
#define		GET_HALL6_STATUS		GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_12)

#define		POS_ARRIVED_SIG		Bit_SET


typedef struct 
{
	uint32_t set_pos_tremble_timeout;	// for pos detection tremble
	uint32_t set_oc_tremble_timeout;
	uint32_t set_max_pwm;
	uint32_t set_duty_step;
	uint32_t set_updown_timeout;
	uint8_t  wheel_angle_studied_flag;
	uint16_t wheel_up_angle_value;
	uint16_t wheel_down_angle_value;
}dc_motor_para_t;

typedef struct
{
	uint16_t bldc_to_motherboard_package_cnt;	// for pos detection tremble
	uint16_t motherboard_to_bldc_package_cnt;
}bldc_error_rate;

typedef struct
{
	float err;
	float err_err;
	float last_err;
	float ui;
	float ud;
	float imax;
	float imin;
	float kp;
	float ki;
	float kd;
	float output;
	float last_output;
	float k;
	float ki_flash;

}pid_contorller_dc_motor_t;

/**
* @brief  configure all resources which is needed for dc_motor
* @param  void
* @note   PA0: Position1 interrupt
*		  PA1: Position2 interrupt
*		  PA2: m_ctrl2
*		  PA3: m_ctrl1
*		  PA4: over_current detection
* @retval None
*/
void dc_motor_init(void);
void dc_motor_right_position_update(uint16_t duty);
void dc_motor_left_position_update(uint16_t duty);

/**
* @brief  drive dc_motor to run
* @param  dir: POSITIVE or NEGATIVE
* @note   
* @retval None
*/
/*void dc_run(dc_dir_t dir);*/
/**
* @brief  stop dc_motor
* @param  void
* @note   
* @retval None
*/
/*void dc_stop(void);*/
typedef struct 
{
	uint16_t pos1_arrive_time;
	uint16_t pos2_arrive_time;
	uint16_t pos3_arrive_time;
	uint16_t pos_from_start;
	uint16_t over_current_time;
	uint16_t max_pwm;
	dc_motor_para_t para;
	uint32_t dc_motor_liftup_state;
	uint32_t dc_motor_liftdown_state;
	uint16_t calibrate_dc;
	uint8_t  dc_motor_wheel_state_flag;
	uint32_t dc_motor_wheel_state_seq;
	uint8_t  dc_motor_second_gear_flag;       //���ӱ������жϱ�־λ
	uint8_t  dc_motor_second_gear_start;       //��⵽�����𣬵����ʼ����
	uint8_t  wheel_angle_studied_flag;
	uint16_t wheel_up_angle_value;
	uint16_t wheel_down_angle_value;
}dc_motor_t;
volatile dc_motor_t dc_motor;
#endif