#include "newprotocol.h"
#include "bsp.h"
#include "dc_motor.h"
#include "bldc.h"
#include "print.h"
#include <stdio.h>
#include <string.h>
#include "R1_Protocol.h"
#include "cowa_packet_process.h"
#include "R1_data_struct.h"
#include "stm32f0xx_it.h"
#include "core_cm0.h"
#include "crc16.h"

int handler = 0;

void dma_handler()
{
	handler = cowa_init_dma_receive_buffer(receive_dma, CIRCUL_BUF_LEN, &(DMA1_Channel3->CNDTR));
}

void new_protocol_handler()
{
	if (handler != -1)
	{
		if (cowa_receive_packet(handler, &receive_data) == 1)
		{
			bldc_package_cnt.motherboard_to_bldc_package_cnt++;
			switch (receive_data.group)        
			{
			case COWA_PACKET_GROUP_COMMAND:
				command_reg();
				break;
			case COWA_PACKET_GROUP_COMMAND_NO_EXECUTED_ACK:
				command_reg();
				break;
			case COWA_PACKET_GROUP_COMMAND_NO_COMM_ACK:
				command_reg();
				break;
			case COWA_PACKET_GROUP_COMMAND_NO_ACK:
				command_reg();
				break;
			default:
				break;
			}
		}
	}
}

void command_reg()
{
	switch (receive_data.id)          //���ֿ���ָ��ID
	{
	case GET_BLDC_DC_PARA_CMD:
		get_bldc_dc_para();
		break;
	case SET_BLDC_DC_PARA_CMD:
		set_bldc_dc_para();
		break;
	case BLDC_CLEAR_ERROR_CMD:
		clear_error();
		break;
	case BLDC_SPEED_CMD:
		set_motor_speed();
		break;
	case BLDC_DUTY_CMD:
		set_motor_duty();
		break;
	case SYSTEM_SWITCH_CMD:
		system_switch();
		break;
	case UPDATE_BLDC_FIRMWARE:
		update_bldc_program();
		break;
 //	case OPEN_OR_CLOSE_BLDC_SENSOR:
 //		open_or_close_bldc_sensor();
 //		break;
 //	case SPD_PRINT_CMD:
 //		spd_print();
 //		break;
	//case CLEAR_WHEEL_STUDIED_FLAG:
	//	clear_wheel_angle_studied_flag();
	//	break;
	default:
		break;
	}
}
void get_bldc_dc_para()
{
	uint8_t fram_size_bldc_dc_para;
	bldc_dc_para_t bldc_dc_para;
	bldc_dc_para.bldc_dc_para_list.bldc_pid_kp = motor.pid.kp;
	bldc_dc_para.bldc_dc_para_list.bldc_pid_ki = (int16_t)(motor.pid.ki_flash*100);
	bldc_dc_para.bldc_dc_para_list.bldc_comm_timeout = motor.timeoutofcontrol;
	bldc_dc_para.bldc_dc_para_list.bldc_poles = motor.poles;
	bldc_dc_para.bldc_dc_para_list.bldc_conrol_mode = motor.ctrl_mode;
	bldc_dc_para.bldc_dc_para_list.dc_octremble = dc_motor.para.set_oc_tremble_timeout;
	bldc_dc_para.bldc_dc_para_list.dc_postremble = dc_motor.para.set_pos_tremble_timeout;
	bldc_dc_para.bldc_dc_para_list.dc_pwm_accelerate = dc_motor.para.set_duty_step;
	bldc_dc_para.bldc_dc_para_list.dc_liftdown_timeout_reg = dc_motor.para.set_updown_timeout;
	bldc_dc_para.bldc_dc_para_list.save_para = 0;
	bldc_dc_para.bldc_dc_para_list.bldc_pid_k = (int16_t)(motor.pid.k*100);
	bldc_dc_para.bldc_dc_para_list.dc_max_pwm = dc_motor.para.set_max_pwm;
	send_data_buffer.group = COWA_PACKET_GROUP_ACK_EXECUTED;
	send_data_buffer.id = EXEC_ACK_GET_BLDC_DC_PARA_CMD;
	send_data_buffer.timeStap = receive_data.seq;
	memcpy(send_data_buffer.data, &bldc_dc_para, sizeof(bldc_dc_para_t));
	fram_size_bldc_dc_para = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
	send_to_master(&send_fram_dma, fram_size_bldc_dc_para);
}
void set_bldc_dc_para()
{
	uint8_t fram_size_set_bldc_dc_para;
	int bldc_save_flag = 1, dc_motor_save_flag = 1;
	parameters_t para;
	dc_motor_para_t dc_para;
	bldc_dc_para_t set_bldc_dc_word;
	int16_t  data;
	memcpy(&set_bldc_dc_word, receive_data.data, sizeof(bldc_dc_para_t));
	for (int i=0;i<16;i++)
	{
		switch (i)
		{
		case 0:
			if (set_bldc_dc_word.ctrl_world.bit_field.bldc_pid_kp_flag ==1)
			{
				data = set_bldc_dc_word.bldc_dc_para_list.bldc_pid_kp;	 // 0.01
				motor.pid.kp = (float)(data / 100.0);
			}
			break;
		case 1:
			if (set_bldc_dc_word.ctrl_world.bit_field.bldc_pid_ki_flag == 1)
			{
				data = set_bldc_dc_word.bldc_dc_para_list.bldc_pid_ki;  // 0.01
				motor.pid.ki_flash = (float)(data / 100.0);
			}
			break;
		case 2:
			if (set_bldc_dc_word.ctrl_world.bit_field.bldc_comm_timeout_flag == 1)
			{
				motor.timeoutofcontrol = set_bldc_dc_word.bldc_dc_para_list.bldc_comm_timeout; // ms
			}
			break;
		case 3:
			if (set_bldc_dc_word.ctrl_world.bit_field.bldc_poles_flag == 1)
			{
				motor.poles = set_bldc_dc_word.bldc_dc_para_list.bldc_poles;
			}
			break;
		case 4:
			if (set_bldc_dc_word.ctrl_world.bit_field.bldc_conrol_mode_flag == 1)
			{
				motor.ctrl_mode = set_bldc_dc_word.bldc_dc_para_list.bldc_conrol_mode;
			}
			break;
		case 5:
			if (set_bldc_dc_word.ctrl_world.bit_field.dc_octremble_flag == 1)
			{
				dc_motor.para.set_oc_tremble_timeout = set_bldc_dc_word.bldc_dc_para_list.dc_octremble;
			}
			break;
		case 6:
			if (set_bldc_dc_word.ctrl_world.bit_field.dc_postremble_flag == 1)
			{
				dc_motor.para.set_pos_tremble_timeout = set_bldc_dc_word.bldc_dc_para_list.dc_postremble;
			}
			break;
		case 7:
			if (set_bldc_dc_word.ctrl_world.bit_field.dc_pwm_accelerate_flag == 1)
			{
				data = set_bldc_dc_word.bldc_dc_para_list.dc_pwm_accelerate;
				if (data > 50)
					data = 10;
				dc_motor.para.set_duty_step = data;
			}
			break;
		case 8:
			if (set_bldc_dc_word.ctrl_world.bit_field.dc_liftdown_timeout_reg_flag == 1)
			{
				dc_motor.para.set_updown_timeout = set_bldc_dc_word.bldc_dc_para_list.dc_liftdown_timeout_reg;
			}
			break;
		case 9:
			if (set_bldc_dc_word.ctrl_world.bit_field.save_para_flag == 1)
			{
				if (set_bldc_dc_word.bldc_dc_para_list.save_para == 1)
				{
					dc_para = dc_motor.para;
					dc_motor_save_flag = write_flash(DC_MOTOR_PARA_ADDR, (&dc_para), (sizeof(dc_para) / sizeof(uint32_t) + 1));
					if (0 != dc_motor_save_flag)
					{
						serial.err_tx.addr = serial.rx_data.rtu.addr;
						serial.err_tx.fun_code_err = 0x86;
						serial.err_tx.err |= ERR_RTU_INTERNAL;
						uint16_t crc_temp = crc16(&serial.err_tx, 3);
						serial.err_tx.crc_hi = (crc_temp >> 8) & 0xff;
						serial.err_tx.crc_lo = crc_temp & 0xff;
						return;
					}
				}
				else if (set_bldc_dc_word.bldc_dc_para_list.save_para == 0)
				{
					for (int i = 0; i < 8; i++)
					{
						para.hall_tbl[i] = motor.hall_tbl[i];
						para.hall_tbl_rt[i] = motor.hall_tbl_rt[i];
					}
					para.poles = motor.poles;
					para.pid = motor.pid;
					para.timeout = motor.timeoutofcontrol;
					bldc_save_flag = write_flash(HALL_TBL_ADDR, (&para), sizeof(para) / sizeof(uint32_t));
					if (0 != bldc_save_flag)
					{
						serial.err_tx.addr = serial.rx_data.rtu.addr;
						serial.err_tx.fun_code_err = 0x86;
						serial.err_tx.err |= ERR_RTU_INTERNAL;
						uint16_t crc_temp = crc16(&serial.err_tx, 3);
						serial.err_tx.crc_hi = (crc_temp >> 8) & 0xff;
						serial.err_tx.crc_lo = crc_temp & 0xff;
						return;
					}
				}
			}
			break;
		case 10:
			if (set_bldc_dc_word.ctrl_world.bit_field.bldc_pid_k_flag == 1)
			{
				data = set_bldc_dc_word.bldc_dc_para_list.bldc_pid_k;	 // 0.01
				motor.pid.k = (float)(data / 100.0);
			}
			break;
		case 11:
			if (set_bldc_dc_word.ctrl_world.bit_field.dc_max_pwm_flag == 1)
			{
				data = set_bldc_dc_word.bldc_dc_para_list.dc_max_pwm;
				if (data > 100)
					data = 100;
				dc_motor.para.set_max_pwm = (uint32_t)data;
			}
			break;
		default:
			break;
		}
	}
	if ((receive_data.group == COWA_PACKET_GROUP_COMMAND) || (receive_data.group == COWA_PACKET_GROUP_COMMAND_NO_COMM_ACK))
	{
		send_data_buffer.group = COWA_PACKET_GROUP_ACK_EXECUTED;
		send_data_buffer.id = EXEC_ACK_SET_BLDC_DC_PARA_CMD;
		send_data_buffer.timeStap = receive_data.seq;
		bldc_dc_para_t bldc_dc_para_executed;
		bldc_dc_para_executed.ctrl_world = set_bldc_dc_word.ctrl_world;
		bldc_dc_para_executed.bldc_dc_para_list.bldc_pid_kp = motor.pid.kp;
		bldc_dc_para_executed.bldc_dc_para_list.bldc_pid_ki = motor.pid.ki_flash;
		bldc_dc_para_executed.bldc_dc_para_list.bldc_comm_timeout = motor.timeoutofcontrol;
		bldc_dc_para_executed.bldc_dc_para_list.bldc_poles = motor.poles;
		bldc_dc_para_executed.bldc_dc_para_list.bldc_conrol_mode = motor.ctrl_mode;
		bldc_dc_para_executed.bldc_dc_para_list.dc_octremble = dc_motor.para.set_oc_tremble_timeout;
		bldc_dc_para_executed.bldc_dc_para_list.dc_postremble = dc_motor.para.set_pos_tremble_timeout;
		bldc_dc_para_executed.bldc_dc_para_list.dc_pwm_accelerate = dc_motor.para.set_duty_step;
		bldc_dc_para_executed.bldc_dc_para_list.dc_liftdown_timeout_reg = dc_motor.para.set_updown_timeout;
		bldc_dc_para_executed.bldc_dc_para_list.save_para = 0;
		bldc_dc_para_executed.bldc_dc_para_list.bldc_pid_k = motor.pid.k;
		bldc_dc_para_executed.bldc_dc_para_list.dc_max_pwm = dc_motor.para.set_max_pwm;
		if ((set_bldc_dc_word.ctrl_world.bit_field.save_para_flag == 1)&&((bldc_save_flag&&dc_motor_save_flag)==0))
		{
			bldc_dc_para_executed.bldc_dc_para_list.save_para = 2;
		}
		memcpy(send_data_buffer.data, &bldc_dc_para_executed, sizeof(bldc_dc_para_t));
		fram_size_set_bldc_dc_para = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
		send_to_master(&send_fram_dma, fram_size_set_bldc_dc_para);
	}
}
void set_motor_speed()
{
	static int16_t data = 0;
	bldc_mb_speed_cmd_t bldc_speed;
	memcpy(&bldc_speed, receive_data.data, sizeof(bldc_mb_speed_cmd_t));
	if (data + 100 < bldc_speed.bldc_speed)
		data += 200;
	else if (data - 100 > bldc_speed.bldc_speed)
		data -= 200;
	else
		data = bldc_speed.bldc_speed;

	if (data > 1900)
		data = 1900;
	else if (data < -1900)
		data = -1900;

	if (data < 0)
	{
		motor.dir = NEGATIVE;
		motor.duty = -data;
	}
	else
	{
		motor.dir = POSITIVE;
		motor.duty = data;
	}
	
	motor.tar_spd = data / 10.0;


	if (motor.tar_spd > 80)
	{
		motor.tar_spd = 80;
	}else if (motor.tar_spd < (-80))
	{
		motor.tar_spd = (-80);
	}
	if (motor.tar_spd == 0)
	{
		motor.tar_spd = 0;
	}
	motor.watchdog = 0;
	//if ((receive_data.group == COWA_PACKET_GROUP_COMMAND) || (receive_data.group == COWA_PACKET_GROUP_COMMAND_NO_COMM_ACK))
	//{
	//	motor.motor_set_speed_flag = 1;
	//	motor.motor_set_speed_seq = receive_data.seq;
	//}
}
void set_motor_duty()
{
	int16_t  data;
	bldc_mb_duty_cmd_t bldc_duty;
	memcpy(&bldc_duty, receive_data.data, sizeof(bldc_mb_duty_cmd_t));
	data = bldc_duty.bldc_duty;
	if (data > 100)
	{
		data = 100;
	}
	motor.tar_duty = data / 100.0 * MAX_PWM_DUTY;
	if ((receive_data.group == COWA_PACKET_GROUP_COMMAND) || (receive_data.group == COWA_PACKET_GROUP_COMMAND_NO_COMM_ACK))
	{
		motor.motor_set_duty_flag = 1;
		motor.motor_set_duty_seq = receive_data.seq;
	}
}
void system_switch()
{
	int8_t   data_switch;
	system_switch_cmd_t system_switch_temp;
	memcpy(&system_switch_temp, receive_data.data, sizeof(system_switch_cmd_t));
	for (int i = 0; i < 8; i++)
	{
		switch (i)
		{
		case 0:
			if (system_switch_temp.ctrl_world.bit_field.bldc_learnning_flag == 1)
			{
				bldc_com_identify(&motor);
			}
			break;
		case 1:
			if (system_switch_temp.ctrl_world.bit_field.bldc_enble_disable_flag == 1)
			{
				data_switch = system_switch_temp.system_switch_cmd_list.bit_field.bldc_enble_disable;
				if (data_switch==1)
				{
					if (motor.enabled != 1)
					{
						enable_bldc(&motor);
						bldc_start(&motor);
					}

				}else
				{
					disable_bldc(&motor);
				}
			}
			break;
		case 2:
			if (system_switch_temp.ctrl_world.bit_field.wheel_lift_down_flag == 1)
			{
				data_switch = system_switch_temp.system_switch_cmd_list.bit_field.wheel_lift_down;
				if (data_switch == 1)
				{
					if ((dc_motor.pos_from_start == 0) && (Bit_SET == GET_POS3_ARRIVE))
					{
						dc_motor.dc_motor_liftup_state = TRUE;
						dc_motor.dc_motor_second_gear_flag = 0;
						dc_motor.dc_motor_second_gear_start = 0;
						TIM15->CCR1 = 0;
						dc_motor.pos3_arrive_time++;
						dc_motor.pos_from_start++;
					}
				}else if(data_switch == 0)
				{
					if ((dc_motor.pos_from_start == 0) && (Bit_SET == GET_POS2_ARRIVE))
					{
						dc_motor.dc_motor_liftdown_state = TRUE;
						dc_motor.dc_motor_second_gear_flag = 0;
						dc_motor.dc_motor_second_gear_start = 0;
						TIM15->CCR2 = 0;
						dc_motor.pos2_arrive_time++;
						dc_motor.pos_from_start++;
					}
				}else if (data_switch == 2)
				{
					if (bldc_dc_status.dc_wheel_status == 2)
					{
						dc_motor.dc_motor_second_gear_flag = 0;
						dc_motor.dc_motor_second_gear_start = 1;
						dc_motor.pos_from_start++;
					}
				}else if (data_switch == 3)                  //ֱ���½�������ֹͣ
				{
					if (dc_motor.wheel_down_angle_value < 2000)
					{
						if ((dc_motor.pos_from_start == 0) && (adc_dma[WHEEL_ANGLE_ADC]>(dc_motor.wheel_down_angle_value + 300)))
						{
							dc_motor.dc_motor_liftdown_state = TRUE;
							dc_motor.dc_motor_second_gear_flag = 0;
							dc_motor.dc_motor_second_gear_start = 0;
							TIM15->CCR2 = 0;
							dc_motor.pos1_arrive_time++;
							dc_motor.pos_from_start++;
						}
					}else if (dc_motor.wheel_down_angle_value > 2000)
					{
						if ((dc_motor.pos_from_start == 0) && (adc_dma[WHEEL_ANGLE_ADC] < (dc_motor.wheel_down_angle_value - 300)))
						{
							dc_motor.dc_motor_liftdown_state = TRUE;
							dc_motor.dc_motor_second_gear_flag = 0;
							dc_motor.dc_motor_second_gear_start = 0;
							TIM15->CCR2 = 0;
							dc_motor.pos1_arrive_time++;
							dc_motor.pos_from_start++;
						}
					}
					
				}
			}
			break;
		case 3:
			break;
		default:
			break;
		}
	}
	if ((receive_data.group == COWA_PACKET_GROUP_COMMAND) || (receive_data.group == COWA_PACKET_GROUP_COMMAND_NO_COMM_ACK))
	{
		for (int i = 0; i < 8; i++)
		{
			switch (i)
			{
			case 0:
				if (system_switch_temp.ctrl_world.bit_field.bldc_learnning_flag == 1)
				{
					motor.motor_learning_flag = 1;
					motor.motor_learning_seq = receive_data.seq;
				}
				break;
			case 1:
				if (system_switch_temp.ctrl_world.bit_field.bldc_enble_disable_flag == 1)
				{
					motor.motor_enabled_flag = 1;
					system_switch_executed_ack.system_switch_cmd_list.bit_field.bldc_enble_disable = system_switch_temp.system_switch_cmd_list.bit_field.bldc_enble_disable;
					motor.motor_enabled_seq = receive_data.seq;
				}
				break;
			case 2:
				if (system_switch_temp.ctrl_world.bit_field.wheel_lift_down_flag == 1)
				{
					dc_motor.dc_motor_wheel_state_flag = 1;
					system_switch_executed_ack.system_switch_cmd_list.bit_field.wheel_lift_down = system_switch_temp.system_switch_cmd_list.bit_field.wheel_lift_down;
					dc_motor.dc_motor_wheel_state_seq = receive_data.seq;
				}
				break;
			default:
				break;
			}
		}
	}

}
void update_bldc_program()
{
	uint8_t fram_size_comm_ack;
	cowa_packet_control_common_t comm_ack;
	send_data_buffer.group = COWA_PACKET_GROUP_ACK_EXECUTED;
	send_data_buffer.id = EXEC_ACK_UPDATE_FIRMWARE;
	send_data_buffer.timeStap = receive_data.seq;
	comm_ack.data = 6;
	memcpy(send_data_buffer.data, (int32_t*)(&(comm_ack.data)), sizeof(comm_ack.data));
	fram_size_comm_ack = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
	uint32_t flag_data = FLASH_UPDATE;
	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPERR);
	FLASH_ErasePage(PROGRAM_UPDATE_FLAG_ADDRESS);
	FLASH_ProgramWord(PROGRAM_UPDATE_FLAG_ADDRESS, FLASH_UPDATE);
 	ms_sleep(200);
	send_to_master(&send_fram_dma, fram_size_comm_ack);
	ms_sleep(200);
	NVIC_SystemReset();
}
void open_or_close_bldc_sensor()
{
	memcpy(&(motor.bldc_sensor_state), receive_data.data, 1);
}
// void spd_print()
// {
// 	uint16_t data_temp = (receive_data.data[0]) * 256 + receive_data.data[1];
// 	disable_bldc(&motor);
// 	motor.tar_spd = 0;
// 	enable_bldc(&motor);
// 	motor.tar_spd = data_temp / 10.0;
// 	bldc_start(&motor);
// 	motor.status = TEST;
// 	while (motor.cnt < 1000);
// 	motor.status = NORMAL;
// 	motor.tar_spd = 0;
// 	pid_reset(&motor.pid);
// 	ms_sleep(1000);
// 	disable_bldc(&motor);
// 	motor.cnt = 0;
// 	for (int i = 0; i < 1024; i++)
// 	{
// 		print("%d  %d\r\n", motor.fk_spd_buf[i], motor.fk_output[i]);
// 	}
// }
void clear_error()
{
	clear_error_status_t clear_err;
	memcpy(&clear_err, receive_data.data, sizeof(clear_error_status_t));
	for (int i = 0; i < 8; i++)
	{
		switch (i)
		{
		case 0:
			if (clear_err.ctrl_world.bit_field.err_bldc_hall_flag==1)
			{
				bldc_err.err_bldc_hall = clear_err.bldc_error_status.err_bldc_hall;
			}
			break;
		case 1:
			if (clear_err.ctrl_world.bit_field.err_bldc_hot_flag == 1)
			{
				bldc_err.err_bldc_hot = clear_err.bldc_error_status.err_bldc_hot;
			}
			break;
		case 2:
			if (clear_err.ctrl_world.bit_field.err_bldc_dangerous_flag == 1)
			{
				//bldc_err.err_bldc_dangerous = clear_err.bldc_error_status.err_bldc_dangerous;
				
			}
			break;
		case 3:
			if (clear_err.ctrl_world.bit_field.err_bldc_oc_tremble_flag == 1)
			{
				bldc_err.err_bldc_oc_tremble = clear_err.bldc_error_status.err_bldc_oc_tremble;
			}
			break;
		case 4:
			if (clear_err.ctrl_world.bit_field.err_bldc_vibration_flag == 1)
			{
				bldc_err.err_bldc_oc_tremble = clear_err.bldc_error_status.err_bldc_vibration;
			}
			break;
		default:
			break;
		}
	}
	if ((receive_data.group == COWA_PACKET_GROUP_COMMAND) || (receive_data.group == COWA_PACKET_GROUP_COMMAND_NO_COMM_ACK))
	{
		motor.motor_clear_err_flag = 1;
		motor.motor_clear_err_seq = receive_data.seq;
	}
}
void clear_wheel_angle_studied_flag()
{
	dc_motor_para_t dc_para_erase_flash;
	dc_para_erase_flash = dc_motor.para;
	dc_para_erase_flash.wheel_angle_studied_flag = 0;
	write_flash(DC_MOTOR_PARA_ADDR, (&dc_para_erase_flash), (sizeof(dc_para_erase_flash) / sizeof(uint32_t) + 1));
	ms_sleep(200);
//	NVIC_SystemReset();
}
void send_to_master(uint8_t* buf, uint16_t size)
{
	static uint8_t dma_send_buf[COWA_FRAME_MAX_SIZE];
	while ((DMA1_Channel2->CNDTR) != 0); // �ȴ��ģͣ��������
	DMA1_Channel2->CCR &= (uint16_t)(~DMA_CCR_EN); // Disable
	memcpy(dma_send_buf, buf, size);
	DMA1_Channel2->CMAR = dma_send_buf;
	DMA1_Channel2->CNDTR = size;
	DMA1_Channel2->CCR |= DMA_CCR_EN; 
	bldc_package_cnt.bldc_to_motherboard_package_cnt++;
}
