#include <stm32f0xx_gpio.h>
#include <stm32f0xx_rcc.h>
#include "bsp.h"
#include "bldc.h"
#include "version.h"
#include "newprotocol.h"
#include "print.h"
#include "dc_motor.h"
#include "stm32f0xx_it.h"
#include "cowa_packet_process.h"

cowa_packet_control_abstract_t receive_data;
cowa_packet_data_abstract_t send_data_buffer;
uint8_t receive_dma[CIRCUL_BUF_LEN];
uint16_t adc_dma[2];
motor_t motor;
cowa_frame_t send_fram_dma;
com_t serial;
system_switch_cmd_t system_switch_executed_ack;
bldc_dc_status_t bldc_dc_status;
bldc_error_status_t bldc_err;
int count_i_bus = 0;
uint16_t i_bus[300];
uint16_t num_i_overflow = 0;
bldc_error_rate bldc_package_cnt;

//APP����ͷ����IAP_Set(void)����
//Falsh address
//SRAM Address 0x020000C0


void IAP_Set(void)
{
	uint32_t i = 0;
	/* Relocate by software the vector table to the internal SRAM at 0x20000000 ***/
	/* Copy the vector table from the Flash (mapped at the base of the application
	load address 0x08002800) to the base address of the SRAM at 0x20000000. */
	for (i = 0; i < 48; i++)
	{
		*((uint32_t*)(0x20000000 + (i << 2))) = *(__IO uint32_t*)(ApplicationAddress + (i << 2));
	}
	/* Enable the SYSCFG peripheral clock*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

	/* Remap SRAM at 0x00000000 */
	SYSCFG_MemoryRemapConfig(SYSCFG_MemoryRemap_SRAM);

}

int main()
{
	//IAP_Set();
//	tim14_serialtimout_init();
	usart1_config();
	adc_config();
	SysTickConfig();
	dc_motor_init();
	bldc_init(); 
	dma_handler();
//	clear_wheel_angle_studied_flag();        //��������ֽǶȴ������Ա궨��־λ
	dc_motor_para_t dc_para;                 //�����ֽǶȴ������Ա궨
	dc_para = *(dc_motor_para_t*)(DC_MOTOR_PARA_ADDR);
    if (dc_para.wheel_angle_studied_flag != 1)
	{
		for (int i = 0; i < 5; i++)
		{
			dc_motor.dc_motor_liftup_state = TRUE;
			dc_motor.dc_motor_second_gear_flag = 0;
			dc_motor.dc_motor_second_gear_start = 0;
			TIM15->CCR1 = 0;
			dc_motor.pos3_arrive_time++;
			dc_motor.pos_from_start++;
			ms_sleep(5000);
			dc_para.wheel_up_angle_value = adc_dma[WHEEL_ANGLE_ADC];
			dc_motor.dc_motor_liftdown_state = TRUE;
			dc_motor.dc_motor_second_gear_flag = 0;
			dc_motor.dc_motor_second_gear_start = 0;
			TIM15->CCR2 = 0;
			dc_motor.pos2_arrive_time++;
			dc_motor.pos_from_start++;
			ms_sleep(5000);
			dc_para.wheel_down_angle_value = adc_dma[WHEEL_ANGLE_ADC];
			if (fabs(dc_para.wheel_up_angle_value - dc_para.wheel_down_angle_value)>900)
			{
				dc_para.wheel_angle_studied_flag = 1;
				dc_motor.wheel_angle_studied_flag = 1;
				dc_motor.wheel_down_angle_value = dc_para.wheel_down_angle_value;
				dc_motor.wheel_up_angle_value = dc_para.wheel_up_angle_value;
				write_flash(DC_MOTOR_PARA_ADDR, (&dc_para), (sizeof(dc_para) / sizeof(uint32_t) + 1));
				break;
			}
			else if (fabs(dc_para.wheel_up_angle_value - dc_para.wheel_down_angle_value) < 100)
			{
				dc_para.wheel_angle_studied_flag = 0;
				dc_motor.wheel_angle_studied_flag = 0;
				break;
			}
		}

	}
	else if (dc_para.wheel_angle_studied_flag == 1)
	{
		dc_motor.wheel_angle_studied_flag = dc_para.wheel_angle_studied_flag;
		dc_motor.wheel_down_angle_value = dc_para.wheel_down_angle_value;
		dc_motor.wheel_up_angle_value = dc_para.wheel_up_angle_value;
	}
	
	while (1)
	{
		new_protocol_handler();
//		print("ad_i = %d %d\r\n", adc_dma[I_BUS_ADC], adc_dma[WHEEL_ANGLE_ADC]);
//		print("pos = %d %d %d %d %d %d\r\n", GET_HALL1_STATUS, GET_HALL2_STATUS, GET_HALL3_STATUS, GET_HALL4_STATUS, GET_HALL5_STATUS, GET_HALL6_STATUS);
 		if (motor.bldc_sensor_state == 1)
 		{
 			if (serial.encode_timeout == 1)
 			{
 				uint8_t fram_size_encode;
 				motor.fk_spd_int = motor.fk_spd * 10;
 				send_data_buffer.group = COWA_PACKET_GROUP_DATA;
 				send_data_buffer.id = BLDC_ENCODER_DATA;
 				send_data_buffer.timeStap = serial.system_timeseq;
 				memcpy(send_data_buffer.data, (int16_t*)(&(motor.fk_spd_int)), COWA_FK_SPEED_LEN);
 				memcpy(send_data_buffer.data + COWA_FK_SPEED_LEN, (int32_t*)(&(motor.pos)), COWA_MOTOR_POS_LEN);
 				memcpy(send_data_buffer.data + COWA_FK_SPEED_LEN + COWA_MOTOR_POS_LEN, (uint8_t*)(&bldc_err), COWA_MOTOR_ERR_LEN);
 				memcpy(send_data_buffer.data + COWA_FK_SPEED_LEN + COWA_MOTOR_POS_LEN + COWA_MOTOR_ERR_LEN, (uint8_t*)(&(bldc_dc_status)), COWA_MOTOR_BLDC_DC_STATUS_LEN);
 				memcpy(send_data_buffer.data + COWA_FK_SPEED_LEN + COWA_MOTOR_POS_LEN + COWA_MOTOR_ERR_LEN + COWA_MOTOR_BLDC_DC_STATUS_LEN, (uint8_t*)(&bldc_package_cnt), 4);
 				fram_size_encode = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
 				send_to_master(&send_fram_dma, fram_size_encode);
 				serial.encode_timeout = 0;
 			}
 		}
     /*ACKִ��Ӧ��*/
    if (motor.motor_learning_flag == 1)            //learnning executed ack
		{
			if (bldc_dc_status.bldc_learnning_status == 2)
			{
				uint8_t fram_size_learning_executed;
				send_data_buffer.group = COWA_PACKET_GROUP_ACK_EXECUTED;
				send_data_buffer.id = EXEC_ACK_SYSTEM_SWITCH_CMD;
				send_data_buffer.timeStap = motor.motor_learning_seq;
				bldc_dc_status.bldc_learnning_status = 2;
				memcpy(send_data_buffer.data, &bldc_dc_status, sizeof(bldc_dc_status_t));
				fram_size_learning_executed = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
				send_to_master(&send_fram_dma, fram_size_learning_executed);
				bldc_dc_status.bldc_learnning_status = 0;
				motor.motor_learning_flag = 0;
			}
			else if (bldc_dc_status.bldc_learnning_status == 3)
			{
				uint8_t fram_size_learning_executed;
				send_data_buffer.group = COWA_PACKET_GROUP_ACK_EXECUTED;
				send_data_buffer.id = EXEC_ACK_SYSTEM_SWITCH_CMD;
				send_data_buffer.timeStap = motor.motor_learning_seq;
				bldc_dc_status.bldc_learnning_status = 3;
				memcpy(send_data_buffer.data, &bldc_dc_status, sizeof(bldc_dc_status_t));
				fram_size_learning_executed = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
				send_to_master(&send_fram_dma, fram_size_learning_executed);
				bldc_dc_status.bldc_learnning_status = 0;
				motor.motor_learning_flag = 0;
			}
		}
    if (motor.motor_enabled_flag == 1)     //enable executed ack
		{
			if (system_switch_executed_ack.system_switch_cmd_list.bit_field.bldc_enble_disable == 1)
			{
				if (motor.enabled == 1)
				{
					uint8_t fram_size_enabled_executed;
					send_data_buffer.group = COWA_PACKET_GROUP_ACK_EXECUTED;
					send_data_buffer.id = EXEC_ACK_SYSTEM_SWITCH_CMD;
					send_data_buffer.timeStap = motor.motor_enabled_seq;
					bldc_dc_status.bldc_enabled_status = 1;
					memcpy(send_data_buffer.data, &bldc_dc_status, sizeof(bldc_dc_status_t));
					fram_size_enabled_executed = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
					send_to_master(&send_fram_dma, fram_size_enabled_executed);
					motor.motor_enabled_flag = 0;
				}
			}
			else if (system_switch_executed_ack.system_switch_cmd_list.bit_field.bldc_enble_disable == 0)
			{
				if (motor.enabled == 0)
				{
					uint8_t fram_size_enabled_executed;
					send_data_buffer.group = COWA_PACKET_GROUP_ACK_EXECUTED;
					send_data_buffer.id = EXEC_ACK_SYSTEM_SWITCH_CMD;
					send_data_buffer.timeStap = motor.motor_enabled_seq;
					bldc_dc_status.bldc_enabled_status = 0;
					memcpy(send_data_buffer.data, &bldc_dc_status, sizeof(bldc_dc_status_t));
					fram_size_enabled_executed = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
					send_to_master(&send_fram_dma, fram_size_enabled_executed);
					motor.motor_enabled_flag = 0;
				}
			}
		}
    if (dc_motor.dc_motor_wheel_state_flag == 1)   //wheel_liftdown executed ack
		{
			if (system_switch_executed_ack.system_switch_cmd_list.bit_field.wheel_lift_down == 1)
			{
				if (bldc_dc_status.dc_wheel_status == 1)
				{
					uint8_t fram_size_wheel_executed;
					send_data_buffer.group = COWA_PACKET_GROUP_ACK_EXECUTED;
					send_data_buffer.id = EXEC_ACK_SYSTEM_SWITCH_CMD;
					send_data_buffer.timeStap = dc_motor.dc_motor_wheel_state_seq;
					bldc_dc_status.dc_wheel_status = 1;
					memcpy(send_data_buffer.data, &bldc_dc_status, sizeof(bldc_dc_status_t));
					fram_size_wheel_executed = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
					send_to_master(&send_fram_dma, fram_size_wheel_executed);
					dc_motor.dc_motor_wheel_state_flag = 0;
				}
				else if (bldc_dc_status.dc_wheel_status == 3)
				{
					uint8_t fram_size_wheel_executed;
					send_data_buffer.group = COWA_PACKET_GROUP_ACK_EXECUTED;
					send_data_buffer.id = EXEC_ACK_SYSTEM_SWITCH_CMD;
					send_data_buffer.timeStap = dc_motor.dc_motor_wheel_state_seq;
					bldc_dc_status.dc_wheel_status = 3;
					memcpy(send_data_buffer.data, &bldc_dc_status, sizeof(bldc_dc_status_t));
					fram_size_wheel_executed = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
					send_to_master(&send_fram_dma, fram_size_wheel_executed);
					dc_motor.dc_motor_wheel_state_flag = 0;
				}
			}
        else if (system_switch_executed_ack.system_switch_cmd_list.bit_field.wheel_lift_down == 0)
			{
				if (bldc_dc_status.dc_wheel_status == 2)
				{
					uint8_t fram_size_wheel_executed;
					send_data_buffer.group = COWA_PACKET_GROUP_ACK_EXECUTED;
					send_data_buffer.id = EXEC_ACK_SYSTEM_SWITCH_CMD;
					send_data_buffer.timeStap = dc_motor.dc_motor_wheel_state_seq;
					bldc_dc_status.dc_wheel_status = 2;
					memcpy(send_data_buffer.data, &bldc_dc_status, sizeof(bldc_dc_status_t));
					fram_size_wheel_executed = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
					send_to_master(&send_fram_dma, fram_size_wheel_executed);
					dc_motor.dc_motor_wheel_state_flag = 0;
				}
				else if (bldc_dc_status.dc_wheel_status == 3)
				{
					uint8_t fram_size_wheel_executed;
					send_data_buffer.group = COWA_PACKET_GROUP_ACK_EXECUTED;
					send_data_buffer.id = EXEC_ACK_SYSTEM_SWITCH_CMD;
					send_data_buffer.timeStap = dc_motor.dc_motor_wheel_state_seq;
					bldc_dc_status.dc_wheel_status = 3;
					memcpy(send_data_buffer.data, &bldc_dc_status, sizeof(bldc_dc_status_t));
					fram_size_wheel_executed = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
					send_to_master(&send_fram_dma, fram_size_wheel_executed);
					dc_motor.dc_motor_wheel_state_flag = 0;
				}
				else if (bldc_dc_status.dc_wheel_status == 4)
				{
					uint8_t fram_size_wheel_executed;
					send_data_buffer.group = COWA_PACKET_GROUP_ACK_EXECUTED;
					send_data_buffer.id = EXEC_ACK_SYSTEM_SWITCH_CMD;
					send_data_buffer.timeStap = dc_motor.dc_motor_wheel_state_seq;
					bldc_dc_status.dc_wheel_status = 4;
					memcpy(send_data_buffer.data, &bldc_dc_status, sizeof(bldc_dc_status_t));
					fram_size_wheel_executed = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
					send_to_master(&send_fram_dma, fram_size_wheel_executed);
					dc_motor.dc_motor_wheel_state_flag = 0;
				}
			}
		}
	if (motor.motor_clear_err_flag == 1)
	{
		uint8_t fram_size_clear_err_executed;
		clear_error_status_t clear_err_executed;
		send_data_buffer.group = COWA_PACKET_GROUP_ACK_EXECUTED;
		send_data_buffer.id = EXEC_ACK_BLDC_CLEAR_ERROR_CMD;
		send_data_buffer.timeStap = motor.motor_clear_err_seq;
		memcpy(send_data_buffer.data, (int8_t*)(&bldc_err), COWA_MOTOR_ERR_LEN);
		fram_size_clear_err_executed = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
		send_to_master(&send_fram_dma, fram_size_clear_err_executed);
		motor.motor_clear_err_flag = 0;
	}
//  if (motor.motor_set_speed_flag == 1)
//		{
//			if (fabs(motor.tar_spd - motor.fk_spd) < 1)
//			{
//				uint8_t fram_size_set_speed_executed;
//				send_data_buffer.group = COWA_PACKET_GROUP_ACK_EXECUTED;
//				send_data_buffer.id = EXEC_ACK_BLDC_SPEED_CMD;
//				send_data_buffer.timeStap = motor.motor_set_speed_seq;
//				motor.fk_spd_int = motor.fk_spd * 10;
//				memcpy(send_data_buffer.data, (int16_t*)(&(motor.fk_spd_int)), COWA_FK_SPEED_LEN);
//				fram_size_set_speed_executed = cowa_pack_frame(&send_data_buffer, &send_fram_dma);
//				send_to_master(&send_fram_dma, fram_size_set_speed_executed);
//				motor.motor_set_speed_flag = 0;
//			}
//		}
  
#if 1
    /*�񶯼��*/
		fft_test();
    /*1s��ʱ�洢����ֵ������������*/
		if (motor.i_bus_count_tick > 1000)
		{
			if ((i_bus[count_i_bus] < I_BUS_TREMBLE) && (adc_dma[I_BUS_ADC] > I_BUS_TREMBLE))
			{
				num_i_overflow++;
				if (num_i_overflow > 150)
				{
//					disable_bldc(&motor);
					bldc_err.err_bldc_hot = 1;
#ifdef BLDC_TAG_TEST
					print("the motor is very hot!\r\n");
#endif
				}
			}
			else if ((i_bus[count_i_bus] > I_BUS_TREMBLE) && (adc_dma[I_BUS_ADC] < I_BUS_TREMBLE))
			{
				if (num_i_overflow > 0)
				{
					num_i_overflow--;
					if (num_i_overflow < 50)          //�ۼƴ��������С��50���ָ�����״̬����
					{
						bldc_err.err_bldc_hot = 0;
					}
				}
			}
			if ((i_bus[count_i_bus] < I_BUS_MAX_TREMBLE) && (adc_dma[I_BUS_ADC] > I_BUS_MAX_TREMBLE))
			{
				num_i_overflow = num_i_overflow + 5;
				if (num_i_overflow > 150)
				{
//					disable_bldc(&motor);
					bldc_err.err_bldc_hot = 1;
#ifdef BLDC_TAG_TEST
					print("the motor is very hot!\r\n");
#endif
				}
			}
			else if ((i_bus[count_i_bus] > I_BUS_MAX_TREMBLE) && (adc_dma[I_BUS_ADC] < I_BUS_MAX_TREMBLE))
			{
				if (num_i_overflow > 5)
				{
					num_i_overflow = num_i_overflow - 5;
					if (num_i_overflow < 50)              //�ۼƴ��������С��50���ָ�����״̬����
					{
						bldc_err.err_bldc_hot = 0;
					}
				}
			}
			i_bus[count_i_bus] = adc_dma[I_BUS_ADC];
			count_i_bus++;
			if (count_i_bus >= 300)
			{
				count_i_bus = 0;
			}
			motor.i_bus_count_tick = 0;
		}
#endif

	}
	return 0;
}